import { type GraphQLSchema } from 'graphql';
type hREASchemaParams = {
    appWebSocket: any;
    roleName: string;
    cell?: any;
};
export declare function createHolochainSchema(params: hREASchemaParams): GraphQLSchema;
export {};
