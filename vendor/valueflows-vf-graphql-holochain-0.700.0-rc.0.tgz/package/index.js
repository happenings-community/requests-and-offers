import { makeExecutableSchema } from '@graphql-tools/schema';
import { generateResolvers } from './src/resolvers/index.js';
// @ts-ignore
import { buildSchema, printSchema } from '@valueflows/vf-graphql';
export function createHolochainSchema(params) {
    const cell = {
        callZome: async function (args) {
            return params.appWebSocket.callZome({
                cap_secret: null,
                role_name: params.roleName,
                zome_name: args.zome_name,
                fn_name: args.fn_name,
                payload: args.payload,
            }, 999999);
        }
    };
    const resolvers = generateResolvers(params.cell || cell);
    const enabledVFModules = [
        'util',
        'pagination',
        'history',
        'agent',
        'action',
        'plan',
        'util',
        'commitment',
        'proposal',
        'recipe',
        'process',
        'measurement',
        'observation',
        'process_specification',
        'resource_specification',
        'agreement',
        'intent',
    ];
    const overriddenExtensionSchemas = [];
    // VF 1.0 extension: vf:Proposal.purpose (vf:ProposalPurpose = offer | request).
    // The base @valueflows/vf-graphql schema already declares the `offers` and
    // `requests` queries (resolved in src/queries) but does not carry the
    // `purpose` field on the Proposal type or its input params, so we add it here
    // rather than forking the schema package.
    const vf1ProposalPurposeExtension = `
    enum ProposalPurpose {
      offer
      request
    }
    extend type Proposal {
      "Whether this proposal is published as an offer or a request (vf:Proposal.purpose, VF 1.0)."
      purpose: ProposalPurpose
    }
    extend input ProposalCreateParams {
      purpose: ProposalPurpose
    }
    extend input ProposalUpdateParams {
      purpose: ProposalPurpose
    }

    extend type ResourceSpecification {
      "Whether this specification is used as a medium of exchange (vf:ResourceSpecification.mediumOfExchange, VF 1.0)."
      mediumOfExchange: Boolean
    }
    extend input ResourceSpecificationCreateParams {
      mediumOfExchange: Boolean
    }
    extend input ResourceSpecificationUpdateParams {
      mediumOfExchange: Boolean
    }

    extend type EconomicEvent {
      "Reciprocal counterpart of realizationOf (vf:EconomicEvent.reciprocalRealizationOf, VF 1.0)."
      reciprocalRealizationOf: Agreement
    }
    extend input EconomicEventCreateParams {
      reciprocalRealizationOf: ID
    }
    extend input EconomicEventUpdateParams {
      reciprocalRealizationOf: ID
    }

    extend type Commitment {
      "Reciprocal counterpart of clauseOf (vf:Commitment.reciprocalClauseOf, VF 1.0)."
      reciprocalClauseOf: Agreement
    }
    extend input CommitmentCreateParams {
      reciprocalClauseOf: ID
    }
    extend input CommitmentUpdateParams {
      reciprocalClauseOf: ID
    }

    extend type EconomicEvent {
      "The claim this event settles (vf:EconomicEvent.settles, VF 1.0)."
      settles: Claim
    }
    extend input EconomicEventCreateParams {
      settles: ID
    }
    extend input EconomicEventUpdateParams {
      settles: ID
    }

    "vf:Claim (VF 1.0): a claim for future economic events in reciprocity for an event that already occurred."
    type Claim {
      id: ID!
      revisionId: ID!
      action: Action!
      resourceClassifiedAs: [URI!]
      resourceQuantity: Measure
      effortQuantity: Measure
      triggeredBy: EconomicEvent!
      due: DateTime
      created: DateTime
      finished: Boolean
      note: String
      agreedIn: URI
      "VF 1.0: the EconomicEvents that settle this claim (reverse of EconomicEvent.settles)."
      settledBy: [EconomicEvent!]
    }
    input ClaimCreateParams {
      action: ID!
      resourceClassifiedAs: [URI!]
      resourceQuantity: IMeasure
      effortQuantity: IMeasure
      triggeredBy: ID!
      due: DateTime
      created: DateTime
      finished: Boolean
      note: String
      agreedIn: URI
    }
    input ClaimUpdateParams {
      revisionId: ID!
      action: ID
      resourceClassifiedAs: [URI!]
      resourceQuantity: IMeasure
      effortQuantity: IMeasure
      triggeredBy: ID
      due: DateTime
      created: DateTime
      finished: Boolean
      note: String
      agreedIn: URI
    }
    type ClaimResponse {
      claim: Claim!
    }
    type ClaimEdge {
      node: Claim!
      cursor: String!
    }
    type ClaimConnection {
      edges: [ClaimEdge!]!
      pageInfo: PageInfo!
    }
    extend type Query {
      claim(id: ID!): Claim
      claims(first: Int, after: String, last: Int, before: String): ClaimConnection
    }
    extend type Mutation {
      createClaim(claim: ClaimCreateParams!): ClaimResponse!
      updateClaim(claim: ClaimUpdateParams!): ClaimResponse!
      deleteClaim(revisionId: ID!): Boolean!
    }

    "vf:SpatialThing (VF 1.0): a physical mappable location."
    type SpatialThing {
      id: ID!
      revisionId: ID!
      name: String!
      mappableAddress: String
      lat: Decimal
      long: Decimal
      alt: Decimal
      note: String
    }
    input SpatialThingCreateParams {
      name: String!
      mappableAddress: String
      lat: Decimal
      long: Decimal
      alt: Decimal
      note: String
    }
    input SpatialThingUpdateParams {
      revisionId: ID!
      name: String
      mappableAddress: String
      lat: Decimal
      long: Decimal
      alt: Decimal
      note: String
    }
    type SpatialThingResponse {
      spatialThing: SpatialThing!
    }
    type SpatialThingEdge {
      node: SpatialThing!
      cursor: String!
    }
    type SpatialThingConnection {
      edges: [SpatialThingEdge!]!
      pageInfo: PageInfo!
    }
    extend type Query {
      spatialThing(id: ID!): SpatialThing
      spatialThings(first: Int, after: String, last: Int, before: String): SpatialThingConnection
    }
    extend type Mutation {
      createSpatialThing(spatialThing: SpatialThingCreateParams!): SpatialThingResponse!
      updateSpatialThing(spatialThing: SpatialThingUpdateParams!): SpatialThingResponse!
      deleteSpatialThing(revisionId: ID!): Boolean!
    }

    "vf:AgreementBundle (VF 1.0): a grouping of agreements."
    type AgreementBundle {
      id: ID!
      revisionId: ID!
      name: String
      note: String
      agreements: [Agreement!]
    }
    input AgreementBundleCreateParams {
      name: String
      note: String
      agreements: [ID!]
    }
    input AgreementBundleUpdateParams {
      revisionId: ID!
      name: String
      note: String
      agreements: [ID!]
    }
    type AgreementBundleResponse {
      agreementBundle: AgreementBundle!
    }
    type AgreementBundleEdge {
      node: AgreementBundle!
      cursor: String!
    }
    type AgreementBundleConnection {
      edges: [AgreementBundleEdge!]!
      pageInfo: PageInfo!
    }
    extend type Query {
      agreementBundle(id: ID!): AgreementBundle
      agreementBundles(first: Int, after: String, last: Int, before: String): AgreementBundleConnection
    }
    extend type Mutation {
      createAgreementBundle(agreementBundle: AgreementBundleCreateParams!): AgreementBundleResponse!
      updateAgreementBundle(agreementBundle: AgreementBundleUpdateParams!): AgreementBundleResponse!
      deleteAgreementBundle(revisionId: ID!): Boolean!
    }
  `;
    const executableSchema = makeExecutableSchema({
        typeDefs: [
            printSchema(buildSchema(enabledVFModules, overriddenExtensionSchemas)),
            vf1ProposalPurposeExtension,
        ],
        resolvers,
    });
    return executableSchema;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsb0JBQW9CLEVBQUUsTUFBTSx1QkFBdUIsQ0FBQztBQUU3RCxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSwwQkFBMEIsQ0FBQztBQUM3RCxhQUFhO0FBQ2IsT0FBTyxFQUFFLFdBQVcsRUFBRSxXQUFXLEVBQUUsTUFBTSx3QkFBd0IsQ0FBQTtBQVFqRSxNQUFNLFVBQVUscUJBQXFCLENBQUMsTUFBd0I7SUFDNUQsTUFBTSxJQUFJLEdBQUc7UUFDWCxRQUFRLEVBQUUsS0FBSyxXQUFVLElBQUk7WUFDM0IsT0FBTyxNQUFNLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQztnQkFDbEMsVUFBVSxFQUFFLElBQUk7Z0JBQ2hCLFNBQVMsRUFBRSxNQUFNLENBQUMsUUFBUTtnQkFDMUIsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO2dCQUN6QixPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87Z0JBQ3JCLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTzthQUN0QixFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ2IsQ0FBQztLQUNGLENBQUE7SUFFRCxNQUFNLFNBQVMsR0FBRyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxDQUFBO0lBQ3hELE1BQU0sZ0JBQWdCLEdBQUc7UUFDdkIsTUFBTTtRQUNOLFlBQVk7UUFDWixTQUFTO1FBQ1QsT0FBTztRQUNQLFFBQVE7UUFDUixNQUFNO1FBQ04sTUFBTTtRQUNOLFlBQVk7UUFDWixVQUFVO1FBQ1YsUUFBUTtRQUNSLFNBQVM7UUFDVCxhQUFhO1FBQ2IsYUFBYTtRQUNiLHVCQUF1QjtRQUN2Qix3QkFBd0I7UUFDeEIsV0FBVztRQUNYLFFBQVE7S0FDVCxDQUFBO0lBRUQsTUFBTSwwQkFBMEIsR0FBRyxFQUFFLENBQUE7SUFFckMsZ0ZBQWdGO0lBQ2hGLDJFQUEyRTtJQUMzRSxzRUFBc0U7SUFDdEUsOEVBQThFO0lBQzlFLDBDQUEwQztJQUMxQyxNQUFNLDJCQUEyQixHQUFHOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBbU5uQyxDQUFBO0lBRUQsTUFBTSxnQkFBZ0IsR0FBRyxvQkFBb0IsQ0FBQztRQUM1QyxRQUFRLEVBQUU7WUFDUixXQUFXLENBQUMsV0FBVyxDQUFDLGdCQUFnQixFQUFFLDBCQUEwQixDQUFDLENBQUM7WUFDdEUsMkJBQTJCO1NBQzVCO1FBQ0QsU0FBUztLQUNWLENBQUMsQ0FBQztJQUVILE9BQU8sZ0JBQWdCLENBQUE7QUFDekIsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IG1ha2VFeGVjdXRhYmxlU2NoZW1hIH0gZnJvbSAnQGdyYXBocWwtdG9vbHMvc2NoZW1hJztcbmltcG9ydCB7IHR5cGUgR3JhcGhRTFNjaGVtYSB9IGZyb20gJ2dyYXBocWwnO1xuaW1wb3J0IHsgZ2VuZXJhdGVSZXNvbHZlcnMgfSBmcm9tICcuL3NyYy9yZXNvbHZlcnMvaW5kZXguanMnO1xuLy8gQHRzLWlnbm9yZVxuaW1wb3J0IHsgYnVpbGRTY2hlbWEsIHByaW50U2NoZW1hIH0gZnJvbSAnQHZhbHVlZmxvd3MvdmYtZ3JhcGhxbCdcblxudHlwZSBoUkVBU2NoZW1hUGFyYW1zID0ge1xuICBhcHBXZWJTb2NrZXQ6IGFueTtcbiAgcm9sZU5hbWU6IHN0cmluZztcbiAgY2VsbD86IGFueTsgLy8gSWYgeW91IHdhbnQgdG8gcGFzcyBhIGNlbGwgaW5zdGVhZCBvZiBhcHBXZWJTb2NrZXQgYW5kIHJvbGVOYW1lXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVIb2xvY2hhaW5TY2hlbWEocGFyYW1zOiBoUkVBU2NoZW1hUGFyYW1zKTogR3JhcGhRTFNjaGVtYSB7XG4gIGNvbnN0IGNlbGwgPSB7XG4gICAgY2FsbFpvbWU6IGFzeW5jIGZ1bmN0aW9uKGFyZ3MpIHtcbiAgICAgIHJldHVybiBwYXJhbXMuYXBwV2ViU29ja2V0LmNhbGxab21lKHtcbiAgICAgICAgY2FwX3NlY3JldDogbnVsbCxcbiAgICAgICAgcm9sZV9uYW1lOiBwYXJhbXMucm9sZU5hbWUsXG4gICAgICAgIHpvbWVfbmFtZTogYXJncy56b21lX25hbWUsXG4gICAgICAgIGZuX25hbWU6IGFyZ3MuZm5fbmFtZSxcbiAgICAgICAgcGF5bG9hZDogYXJncy5wYXlsb2FkLFxuICAgICAgfSwgOTk5OTk5KTtcbiAgICB9XG4gIH1cblxuICBjb25zdCByZXNvbHZlcnMgPSBnZW5lcmF0ZVJlc29sdmVycyhwYXJhbXMuY2VsbCB8fCBjZWxsKVxuICBjb25zdCBlbmFibGVkVkZNb2R1bGVzID0gW1xuICAgICd1dGlsJyxcbiAgICAncGFnaW5hdGlvbicsXG4gICAgJ2hpc3RvcnknLFxuICAgICdhZ2VudCcsXG4gICAgJ2FjdGlvbicsXG4gICAgJ3BsYW4nLFxuICAgICd1dGlsJyxcbiAgICAnY29tbWl0bWVudCcsXG4gICAgJ3Byb3Bvc2FsJyxcbiAgICAncmVjaXBlJyxcbiAgICAncHJvY2VzcycsXG4gICAgJ21lYXN1cmVtZW50JyxcbiAgICAnb2JzZXJ2YXRpb24nLFxuICAgICdwcm9jZXNzX3NwZWNpZmljYXRpb24nLFxuICAgICdyZXNvdXJjZV9zcGVjaWZpY2F0aW9uJyxcbiAgICAnYWdyZWVtZW50JyxcbiAgICAnaW50ZW50JyxcbiAgXVxuXG4gIGNvbnN0IG92ZXJyaWRkZW5FeHRlbnNpb25TY2hlbWFzID0gW11cblxuICAvLyBWRiAxLjAgZXh0ZW5zaW9uOiB2ZjpQcm9wb3NhbC5wdXJwb3NlICh2ZjpQcm9wb3NhbFB1cnBvc2UgPSBvZmZlciB8IHJlcXVlc3QpLlxuICAvLyBUaGUgYmFzZSBAdmFsdWVmbG93cy92Zi1ncmFwaHFsIHNjaGVtYSBhbHJlYWR5IGRlY2xhcmVzIHRoZSBgb2ZmZXJzYCBhbmRcbiAgLy8gYHJlcXVlc3RzYCBxdWVyaWVzIChyZXNvbHZlZCBpbiBzcmMvcXVlcmllcykgYnV0IGRvZXMgbm90IGNhcnJ5IHRoZVxuICAvLyBgcHVycG9zZWAgZmllbGQgb24gdGhlIFByb3Bvc2FsIHR5cGUgb3IgaXRzIGlucHV0IHBhcmFtcywgc28gd2UgYWRkIGl0IGhlcmVcbiAgLy8gcmF0aGVyIHRoYW4gZm9ya2luZyB0aGUgc2NoZW1hIHBhY2thZ2UuXG4gIGNvbnN0IHZmMVByb3Bvc2FsUHVycG9zZUV4dGVuc2lvbiA9IGBcbiAgICBlbnVtIFByb3Bvc2FsUHVycG9zZSB7XG4gICAgICBvZmZlclxuICAgICAgcmVxdWVzdFxuICAgIH1cbiAgICBleHRlbmQgdHlwZSBQcm9wb3NhbCB7XG4gICAgICBcIldoZXRoZXIgdGhpcyBwcm9wb3NhbCBpcyBwdWJsaXNoZWQgYXMgYW4gb2ZmZXIgb3IgYSByZXF1ZXN0ICh2ZjpQcm9wb3NhbC5wdXJwb3NlLCBWRiAxLjApLlwiXG4gICAgICBwdXJwb3NlOiBQcm9wb3NhbFB1cnBvc2VcbiAgICB9XG4gICAgZXh0ZW5kIGlucHV0IFByb3Bvc2FsQ3JlYXRlUGFyYW1zIHtcbiAgICAgIHB1cnBvc2U6IFByb3Bvc2FsUHVycG9zZVxuICAgIH1cbiAgICBleHRlbmQgaW5wdXQgUHJvcG9zYWxVcGRhdGVQYXJhbXMge1xuICAgICAgcHVycG9zZTogUHJvcG9zYWxQdXJwb3NlXG4gICAgfVxuXG4gICAgZXh0ZW5kIHR5cGUgUmVzb3VyY2VTcGVjaWZpY2F0aW9uIHtcbiAgICAgIFwiV2hldGhlciB0aGlzIHNwZWNpZmljYXRpb24gaXMgdXNlZCBhcyBhIG1lZGl1bSBvZiBleGNoYW5nZSAodmY6UmVzb3VyY2VTcGVjaWZpY2F0aW9uLm1lZGl1bU9mRXhjaGFuZ2UsIFZGIDEuMCkuXCJcbiAgICAgIG1lZGl1bU9mRXhjaGFuZ2U6IEJvb2xlYW5cbiAgICB9XG4gICAgZXh0ZW5kIGlucHV0IFJlc291cmNlU3BlY2lmaWNhdGlvbkNyZWF0ZVBhcmFtcyB7XG4gICAgICBtZWRpdW1PZkV4Y2hhbmdlOiBCb29sZWFuXG4gICAgfVxuICAgIGV4dGVuZCBpbnB1dCBSZXNvdXJjZVNwZWNpZmljYXRpb25VcGRhdGVQYXJhbXMge1xuICAgICAgbWVkaXVtT2ZFeGNoYW5nZTogQm9vbGVhblxuICAgIH1cblxuICAgIGV4dGVuZCB0eXBlIEVjb25vbWljRXZlbnQge1xuICAgICAgXCJSZWNpcHJvY2FsIGNvdW50ZXJwYXJ0IG9mIHJlYWxpemF0aW9uT2YgKHZmOkVjb25vbWljRXZlbnQucmVjaXByb2NhbFJlYWxpemF0aW9uT2YsIFZGIDEuMCkuXCJcbiAgICAgIHJlY2lwcm9jYWxSZWFsaXphdGlvbk9mOiBBZ3JlZW1lbnRcbiAgICB9XG4gICAgZXh0ZW5kIGlucHV0IEVjb25vbWljRXZlbnRDcmVhdGVQYXJhbXMge1xuICAgICAgcmVjaXByb2NhbFJlYWxpemF0aW9uT2Y6IElEXG4gICAgfVxuICAgIGV4dGVuZCBpbnB1dCBFY29ub21pY0V2ZW50VXBkYXRlUGFyYW1zIHtcbiAgICAgIHJlY2lwcm9jYWxSZWFsaXphdGlvbk9mOiBJRFxuICAgIH1cblxuICAgIGV4dGVuZCB0eXBlIENvbW1pdG1lbnQge1xuICAgICAgXCJSZWNpcHJvY2FsIGNvdW50ZXJwYXJ0IG9mIGNsYXVzZU9mICh2ZjpDb21taXRtZW50LnJlY2lwcm9jYWxDbGF1c2VPZiwgVkYgMS4wKS5cIlxuICAgICAgcmVjaXByb2NhbENsYXVzZU9mOiBBZ3JlZW1lbnRcbiAgICB9XG4gICAgZXh0ZW5kIGlucHV0IENvbW1pdG1lbnRDcmVhdGVQYXJhbXMge1xuICAgICAgcmVjaXByb2NhbENsYXVzZU9mOiBJRFxuICAgIH1cbiAgICBleHRlbmQgaW5wdXQgQ29tbWl0bWVudFVwZGF0ZVBhcmFtcyB7XG4gICAgICByZWNpcHJvY2FsQ2xhdXNlT2Y6IElEXG4gICAgfVxuXG4gICAgZXh0ZW5kIHR5cGUgRWNvbm9taWNFdmVudCB7XG4gICAgICBcIlRoZSBjbGFpbSB0aGlzIGV2ZW50IHNldHRsZXMgKHZmOkVjb25vbWljRXZlbnQuc2V0dGxlcywgVkYgMS4wKS5cIlxuICAgICAgc2V0dGxlczogQ2xhaW1cbiAgICB9XG4gICAgZXh0ZW5kIGlucHV0IEVjb25vbWljRXZlbnRDcmVhdGVQYXJhbXMge1xuICAgICAgc2V0dGxlczogSURcbiAgICB9XG4gICAgZXh0ZW5kIGlucHV0IEVjb25vbWljRXZlbnRVcGRhdGVQYXJhbXMge1xuICAgICAgc2V0dGxlczogSURcbiAgICB9XG5cbiAgICBcInZmOkNsYWltIChWRiAxLjApOiBhIGNsYWltIGZvciBmdXR1cmUgZWNvbm9taWMgZXZlbnRzIGluIHJlY2lwcm9jaXR5IGZvciBhbiBldmVudCB0aGF0IGFscmVhZHkgb2NjdXJyZWQuXCJcbiAgICB0eXBlIENsYWltIHtcbiAgICAgIGlkOiBJRCFcbiAgICAgIHJldmlzaW9uSWQ6IElEIVxuICAgICAgYWN0aW9uOiBBY3Rpb24hXG4gICAgICByZXNvdXJjZUNsYXNzaWZpZWRBczogW1VSSSFdXG4gICAgICByZXNvdXJjZVF1YW50aXR5OiBNZWFzdXJlXG4gICAgICBlZmZvcnRRdWFudGl0eTogTWVhc3VyZVxuICAgICAgdHJpZ2dlcmVkQnk6IEVjb25vbWljRXZlbnQhXG4gICAgICBkdWU6IERhdGVUaW1lXG4gICAgICBjcmVhdGVkOiBEYXRlVGltZVxuICAgICAgZmluaXNoZWQ6IEJvb2xlYW5cbiAgICAgIG5vdGU6IFN0cmluZ1xuICAgICAgYWdyZWVkSW46IFVSSVxuICAgICAgXCJWRiAxLjA6IHRoZSBFY29ub21pY0V2ZW50cyB0aGF0IHNldHRsZSB0aGlzIGNsYWltIChyZXZlcnNlIG9mIEVjb25vbWljRXZlbnQuc2V0dGxlcykuXCJcbiAgICAgIHNldHRsZWRCeTogW0Vjb25vbWljRXZlbnQhXVxuICAgIH1cbiAgICBpbnB1dCBDbGFpbUNyZWF0ZVBhcmFtcyB7XG4gICAgICBhY3Rpb246IElEIVxuICAgICAgcmVzb3VyY2VDbGFzc2lmaWVkQXM6IFtVUkkhXVxuICAgICAgcmVzb3VyY2VRdWFudGl0eTogSU1lYXN1cmVcbiAgICAgIGVmZm9ydFF1YW50aXR5OiBJTWVhc3VyZVxuICAgICAgdHJpZ2dlcmVkQnk6IElEIVxuICAgICAgZHVlOiBEYXRlVGltZVxuICAgICAgY3JlYXRlZDogRGF0ZVRpbWVcbiAgICAgIGZpbmlzaGVkOiBCb29sZWFuXG4gICAgICBub3RlOiBTdHJpbmdcbiAgICAgIGFncmVlZEluOiBVUklcbiAgICB9XG4gICAgaW5wdXQgQ2xhaW1VcGRhdGVQYXJhbXMge1xuICAgICAgcmV2aXNpb25JZDogSUQhXG4gICAgICBhY3Rpb246IElEXG4gICAgICByZXNvdXJjZUNsYXNzaWZpZWRBczogW1VSSSFdXG4gICAgICByZXNvdXJjZVF1YW50aXR5OiBJTWVhc3VyZVxuICAgICAgZWZmb3J0UXVhbnRpdHk6IElNZWFzdXJlXG4gICAgICB0cmlnZ2VyZWRCeTogSURcbiAgICAgIGR1ZTogRGF0ZVRpbWVcbiAgICAgIGNyZWF0ZWQ6IERhdGVUaW1lXG4gICAgICBmaW5pc2hlZDogQm9vbGVhblxuICAgICAgbm90ZTogU3RyaW5nXG4gICAgICBhZ3JlZWRJbjogVVJJXG4gICAgfVxuICAgIHR5cGUgQ2xhaW1SZXNwb25zZSB7XG4gICAgICBjbGFpbTogQ2xhaW0hXG4gICAgfVxuICAgIHR5cGUgQ2xhaW1FZGdlIHtcbiAgICAgIG5vZGU6IENsYWltIVxuICAgICAgY3Vyc29yOiBTdHJpbmchXG4gICAgfVxuICAgIHR5cGUgQ2xhaW1Db25uZWN0aW9uIHtcbiAgICAgIGVkZ2VzOiBbQ2xhaW1FZGdlIV0hXG4gICAgICBwYWdlSW5mbzogUGFnZUluZm8hXG4gICAgfVxuICAgIGV4dGVuZCB0eXBlIFF1ZXJ5IHtcbiAgICAgIGNsYWltKGlkOiBJRCEpOiBDbGFpbVxuICAgICAgY2xhaW1zKGZpcnN0OiBJbnQsIGFmdGVyOiBTdHJpbmcsIGxhc3Q6IEludCwgYmVmb3JlOiBTdHJpbmcpOiBDbGFpbUNvbm5lY3Rpb25cbiAgICB9XG4gICAgZXh0ZW5kIHR5cGUgTXV0YXRpb24ge1xuICAgICAgY3JlYXRlQ2xhaW0oY2xhaW06IENsYWltQ3JlYXRlUGFyYW1zISk6IENsYWltUmVzcG9uc2UhXG4gICAgICB1cGRhdGVDbGFpbShjbGFpbTogQ2xhaW1VcGRhdGVQYXJhbXMhKTogQ2xhaW1SZXNwb25zZSFcbiAgICAgIGRlbGV0ZUNsYWltKHJldmlzaW9uSWQ6IElEISk6IEJvb2xlYW4hXG4gICAgfVxuXG4gICAgXCJ2ZjpTcGF0aWFsVGhpbmcgKFZGIDEuMCk6IGEgcGh5c2ljYWwgbWFwcGFibGUgbG9jYXRpb24uXCJcbiAgICB0eXBlIFNwYXRpYWxUaGluZyB7XG4gICAgICBpZDogSUQhXG4gICAgICByZXZpc2lvbklkOiBJRCFcbiAgICAgIG5hbWU6IFN0cmluZyFcbiAgICAgIG1hcHBhYmxlQWRkcmVzczogU3RyaW5nXG4gICAgICBsYXQ6IERlY2ltYWxcbiAgICAgIGxvbmc6IERlY2ltYWxcbiAgICAgIGFsdDogRGVjaW1hbFxuICAgICAgbm90ZTogU3RyaW5nXG4gICAgfVxuICAgIGlucHV0IFNwYXRpYWxUaGluZ0NyZWF0ZVBhcmFtcyB7XG4gICAgICBuYW1lOiBTdHJpbmchXG4gICAgICBtYXBwYWJsZUFkZHJlc3M6IFN0cmluZ1xuICAgICAgbGF0OiBEZWNpbWFsXG4gICAgICBsb25nOiBEZWNpbWFsXG4gICAgICBhbHQ6IERlY2ltYWxcbiAgICAgIG5vdGU6IFN0cmluZ1xuICAgIH1cbiAgICBpbnB1dCBTcGF0aWFsVGhpbmdVcGRhdGVQYXJhbXMge1xuICAgICAgcmV2aXNpb25JZDogSUQhXG4gICAgICBuYW1lOiBTdHJpbmdcbiAgICAgIG1hcHBhYmxlQWRkcmVzczogU3RyaW5nXG4gICAgICBsYXQ6IERlY2ltYWxcbiAgICAgIGxvbmc6IERlY2ltYWxcbiAgICAgIGFsdDogRGVjaW1hbFxuICAgICAgbm90ZTogU3RyaW5nXG4gICAgfVxuICAgIHR5cGUgU3BhdGlhbFRoaW5nUmVzcG9uc2Uge1xuICAgICAgc3BhdGlhbFRoaW5nOiBTcGF0aWFsVGhpbmchXG4gICAgfVxuICAgIHR5cGUgU3BhdGlhbFRoaW5nRWRnZSB7XG4gICAgICBub2RlOiBTcGF0aWFsVGhpbmchXG4gICAgICBjdXJzb3I6IFN0cmluZyFcbiAgICB9XG4gICAgdHlwZSBTcGF0aWFsVGhpbmdDb25uZWN0aW9uIHtcbiAgICAgIGVkZ2VzOiBbU3BhdGlhbFRoaW5nRWRnZSFdIVxuICAgICAgcGFnZUluZm86IFBhZ2VJbmZvIVxuICAgIH1cbiAgICBleHRlbmQgdHlwZSBRdWVyeSB7XG4gICAgICBzcGF0aWFsVGhpbmcoaWQ6IElEISk6IFNwYXRpYWxUaGluZ1xuICAgICAgc3BhdGlhbFRoaW5ncyhmaXJzdDogSW50LCBhZnRlcjogU3RyaW5nLCBsYXN0OiBJbnQsIGJlZm9yZTogU3RyaW5nKTogU3BhdGlhbFRoaW5nQ29ubmVjdGlvblxuICAgIH1cbiAgICBleHRlbmQgdHlwZSBNdXRhdGlvbiB7XG4gICAgICBjcmVhdGVTcGF0aWFsVGhpbmcoc3BhdGlhbFRoaW5nOiBTcGF0aWFsVGhpbmdDcmVhdGVQYXJhbXMhKTogU3BhdGlhbFRoaW5nUmVzcG9uc2UhXG4gICAgICB1cGRhdGVTcGF0aWFsVGhpbmcoc3BhdGlhbFRoaW5nOiBTcGF0aWFsVGhpbmdVcGRhdGVQYXJhbXMhKTogU3BhdGlhbFRoaW5nUmVzcG9uc2UhXG4gICAgICBkZWxldGVTcGF0aWFsVGhpbmcocmV2aXNpb25JZDogSUQhKTogQm9vbGVhbiFcbiAgICB9XG5cbiAgICBcInZmOkFncmVlbWVudEJ1bmRsZSAoVkYgMS4wKTogYSBncm91cGluZyBvZiBhZ3JlZW1lbnRzLlwiXG4gICAgdHlwZSBBZ3JlZW1lbnRCdW5kbGUge1xuICAgICAgaWQ6IElEIVxuICAgICAgcmV2aXNpb25JZDogSUQhXG4gICAgICBuYW1lOiBTdHJpbmdcbiAgICAgIG5vdGU6IFN0cmluZ1xuICAgICAgYWdyZWVtZW50czogW0FncmVlbWVudCFdXG4gICAgfVxuICAgIGlucHV0IEFncmVlbWVudEJ1bmRsZUNyZWF0ZVBhcmFtcyB7XG4gICAgICBuYW1lOiBTdHJpbmdcbiAgICAgIG5vdGU6IFN0cmluZ1xuICAgICAgYWdyZWVtZW50czogW0lEIV1cbiAgICB9XG4gICAgaW5wdXQgQWdyZWVtZW50QnVuZGxlVXBkYXRlUGFyYW1zIHtcbiAgICAgIHJldmlzaW9uSWQ6IElEIVxuICAgICAgbmFtZTogU3RyaW5nXG4gICAgICBub3RlOiBTdHJpbmdcbiAgICAgIGFncmVlbWVudHM6IFtJRCFdXG4gICAgfVxuICAgIHR5cGUgQWdyZWVtZW50QnVuZGxlUmVzcG9uc2Uge1xuICAgICAgYWdyZWVtZW50QnVuZGxlOiBBZ3JlZW1lbnRCdW5kbGUhXG4gICAgfVxuICAgIHR5cGUgQWdyZWVtZW50QnVuZGxlRWRnZSB7XG4gICAgICBub2RlOiBBZ3JlZW1lbnRCdW5kbGUhXG4gICAgICBjdXJzb3I6IFN0cmluZyFcbiAgICB9XG4gICAgdHlwZSBBZ3JlZW1lbnRCdW5kbGVDb25uZWN0aW9uIHtcbiAgICAgIGVkZ2VzOiBbQWdyZWVtZW50QnVuZGxlRWRnZSFdIVxuICAgICAgcGFnZUluZm86IFBhZ2VJbmZvIVxuICAgIH1cbiAgICBleHRlbmQgdHlwZSBRdWVyeSB7XG4gICAgICBhZ3JlZW1lbnRCdW5kbGUoaWQ6IElEISk6IEFncmVlbWVudEJ1bmRsZVxuICAgICAgYWdyZWVtZW50QnVuZGxlcyhmaXJzdDogSW50LCBhZnRlcjogU3RyaW5nLCBsYXN0OiBJbnQsIGJlZm9yZTogU3RyaW5nKTogQWdyZWVtZW50QnVuZGxlQ29ubmVjdGlvblxuICAgIH1cbiAgICBleHRlbmQgdHlwZSBNdXRhdGlvbiB7XG4gICAgICBjcmVhdGVBZ3JlZW1lbnRCdW5kbGUoYWdyZWVtZW50QnVuZGxlOiBBZ3JlZW1lbnRCdW5kbGVDcmVhdGVQYXJhbXMhKTogQWdyZWVtZW50QnVuZGxlUmVzcG9uc2UhXG4gICAgICB1cGRhdGVBZ3JlZW1lbnRCdW5kbGUoYWdyZWVtZW50QnVuZGxlOiBBZ3JlZW1lbnRCdW5kbGVVcGRhdGVQYXJhbXMhKTogQWdyZWVtZW50QnVuZGxlUmVzcG9uc2UhXG4gICAgICBkZWxldGVBZ3JlZW1lbnRCdW5kbGUocmV2aXNpb25JZDogSUQhKTogQm9vbGVhbiFcbiAgICB9XG4gIGBcblxuICBjb25zdCBleGVjdXRhYmxlU2NoZW1hID0gbWFrZUV4ZWN1dGFibGVTY2hlbWEoe1xuICAgIHR5cGVEZWZzOiBbXG4gICAgICBwcmludFNjaGVtYShidWlsZFNjaGVtYShlbmFibGVkVkZNb2R1bGVzLCBvdmVycmlkZGVuRXh0ZW5zaW9uU2NoZW1hcykpLFxuICAgICAgdmYxUHJvcG9zYWxQdXJwb3NlRXh0ZW5zaW9uLFxuICAgIF0sXG4gICAgcmVzb2x2ZXJzLFxuICB9KTtcblxuICByZXR1cm4gZXhlY3V0YWJsZVNjaGVtYVxufVxuIl19