import { OrganizationResponse } from "@valueflows/vf-graphql";
declare const _default: (cell: any) => {
    createOrganization: (root: any, args: any) => Promise<OrganizationResponse>;
    deleteOrganization: (root: any, args: any) => Promise<boolean>;
    updateOrganization: (root: any, args: any) => Promise<OrganizationResponse>;
    createPerson: (root: any, args: any) => Promise<OrganizationResponse>;
    deletePerson: (root: any, args: any) => Promise<boolean>;
    updatePerson: (root: any, args: any) => Promise<OrganizationResponse>;
};
export default _default;
