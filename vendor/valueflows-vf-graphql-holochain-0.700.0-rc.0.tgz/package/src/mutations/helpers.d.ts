export declare function createEntry(cell: any, entryType: string, payload: any): Promise<{
    [x: string]: any;
}>;
export declare function updateEntry(cell: any, entryType: string, payload: any): Promise<{
    [x: string]: any;
}>;
export declare function deleteEntry(cell: any, typeName: string, args: any): Promise<boolean>;
