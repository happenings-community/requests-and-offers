declare const _default: (cell: any) => any;
export default _default;
