import { Action } from '@valueflows/vf-graphql';
declare const _default: (cell: any) => {
    actions: (root: any, args: any) => Promise<Array<Action>>;
    action: (root: any, args: any) => Promise<Action>;
};
export default _default;
