import { AgentConnection, Agent } from '@valueflows/vf-graphql';
import { PagingParams } from '../types.js';
declare const _default: (cell: any) => {
    agents: (root: any, args: PagingParams) => Promise<AgentConnection>;
    agent: (root: any, args: {
        id: string;
    }) => Promise<Agent>;
    organizations: (root: any, args: PagingParams) => Promise<AgentConnection>;
    organization: (root: any, args: {
        id: string;
    }) => Promise<Agent>;
    people: (root: any, args: PagingParams) => Promise<AgentConnection>;
    person: (root: any, args: {
        id: string;
    }) => Promise<Agent>;
};
export default _default;
