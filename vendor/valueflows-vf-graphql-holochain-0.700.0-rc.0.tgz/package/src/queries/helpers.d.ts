export declare function getOne(cell: any, type: string, args: any): Promise<any>;
export declare function getAll(cell: any, type: string, args: any): Promise<{
    pageInfo: {
        endCursor: null;
        hasNextPage: boolean;
        hasPreviousPage: boolean;
        pageLimit: null;
        startCursor: null;
        totalCount: null;
    };
    edges: any;
}>;
