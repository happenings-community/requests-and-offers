export declare const generateResolvers: (cell: any) => any;
