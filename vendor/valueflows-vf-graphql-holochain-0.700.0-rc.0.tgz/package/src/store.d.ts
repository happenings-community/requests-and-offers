export declare const entryLookup: Record<string, any>;
export declare function getEntryFromStore(hash: string): any;
export declare function addEntryToStore(hash: string, entry: any): void;
export declare function removeEntryFromStore(hash: string): void;
export declare const recentlyFetchedRevisionIds: Record<string, {
    revisionId: string;
    timestamp: number;
}>;
export declare function getLatestRevisionId(hash: string, passedSeconds: number): string | null;
export declare function getLastUpdateTime(hash: string): number | null;
export declare function updateLatestRevision(originalId: string, revisionId: string): void;
