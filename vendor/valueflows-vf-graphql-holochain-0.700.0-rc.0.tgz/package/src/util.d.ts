import { type Link } from '@holochain/client';
import { PagingParams } from './types.js';
type ExtractIdsOutput = {
    id: string;
    revisionId: string;
    entry: any;
};
type ExtractIdsInput = {
    id: string;
    revisionId: string;
    [key: string]: any;
};
export declare function extractIds(obj: ExtractIdsInput): ExtractIdsOutput;
export declare function getPaginatedCollection(cell: any, linkFunc: string, entryFunc: string, paginated: PagingParams): Promise<{
    pageInfo: {
        endCursor: null;
        hasNextPage: boolean;
        hasPreviousPage: boolean;
        pageLimit: null;
        startCursor: null;
        totalCount: null;
    };
    edges: any;
}>;
export declare function paginateCollection(collection: any, args: PagingParams): {
    pageInfo: {
        endCursor: null;
        hasNextPage: boolean;
        hasPreviousPage: boolean;
        pageLimit: null;
        startCursor: null;
        totalCount: null;
    };
    edges: any;
};
export declare function getCollectionLinks(cell: any, linkFunc: string, payload: any, paginated?: PagingParams): Promise<Link[]>;
export declare function getCollection(cell: any, linkFunc: string, payload: any, paginated?: PagingParams): Promise<any[]>;
export declare function getEntries(cell: any, list: Link[]): Promise<any[]>;
/**
 * Timestamp of a signed action, across the 0.6 and 0.7 action shapes.
 *
 * Holochain 0.7 splits an Action into `{ header, data }`: the fields every
 * variant shares (author, timestamp, action_seq, prev_action) moved under
 * `header`, and the variant payload under `data`. On 0.6 they sat flat on
 * `content`. Reading only the 0.7 path would break any consumer still on 0.6,
 * and reading only the 0.6 path is what made `meta.retrievedRevision.time`
 * come back empty on 0.7.
 */
export declare function actionTimestamp(content: any): any;
export declare function formatResItem(resItem: any, id: string): any;
export declare function snakeToCamelString(str: string): string;
export declare function snakeToCamel(lib: any): any;
export declare function camelToSnake(lib: any): any;
export declare function detectQuantityValueField(field: any): boolean;
export declare function decodePotentialQuantityValueField(field: any): any;
export declare function findAndDecodeQuantityValueFields(obj: any): any;
export declare function formatDates(obj: any): any;
export declare function reverseFormatDates(obj: any): any;
export declare function pluralize(str: string): string;
export declare function decodeHashFields(obj: any, hashFields: string[]): any;
export declare function getAction(id: string): any;
export {};
