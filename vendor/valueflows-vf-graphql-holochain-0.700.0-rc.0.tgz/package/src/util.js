import { decode } from '@msgpack/msgpack';
import { decodeHashFromBase64, encodeHashToBase64 } from '@holochain/client';
import { getEntryFromStore, addEntryToStore, updateLatestRevision } from './store.js';
export function extractIds(obj) {
    // extract the ids from the object
    let id = obj.id;
    let revisionId = obj.revisionId;
    let output = { id, revisionId, entry: {} };
    let args = { ...obj };
    delete args.id;
    delete args.revisionId;
    output.entry = args;
    return output;
}
export async function getPaginatedCollection(cell, linkFunc, entryFunc, paginated) {
    const collection = await getCollection(cell, linkFunc, null, paginated);
    const paginatedCollection = paginateCollection(collection, paginated);
    return paginatedCollection;
}
export function paginateCollection(collection, args) {
    const paginated = collection.map((item) => {
        return {
            __typename: 'AgentEdge',
            cursor: item.id,
            node: {
                ...item,
                __typename: item.agentType
            }
        };
    });
    return {
        pageInfo: {
            endCursor: null,
            hasNextPage: false,
            hasPreviousPage: false,
            pageLimit: null,
            startCursor: null,
            totalCount: null,
        },
        edges: paginated
    };
}
export async function getCollectionLinks(cell, linkFunc, payload, paginated) {
    const result = await cell.callZome({
        zome_name: 'hrea',
        fn_name: linkFunc,
        payload,
    });
    const dedupedLinks = Array.from(result.reduce((map, link) => {
        const encodedTarget = encodeHashToBase64(link.tag);
        if (!map.has(encodedTarget) || (map.get(encodedTarget)?.timestamp ?? 0) < link.timestamp) {
            map.set(encodedTarget, link);
        }
        return map;
    }, new Map()).values());
    return dedupedLinks;
}
export async function getCollection(cell, linkFunc, payload, paginated) {
    const dedupedLinks = await getCollectionLinks(cell, linkFunc, payload, paginated);
    // handle pagination
    if (paginated) {
        const allLinkTags = dedupedLinks.map((link) => encodeHashToBase64(link.tag));
        let sliceBegins = 0;
        let sliceEnds = dedupedLinks.length;
        if (paginated?.first) {
            sliceBegins = Math.max(paginated?.first - 1, sliceBegins);
        }
        else if (paginated?.after) {
            sliceBegins = Math.max((allLinkTags.indexOf(paginated?.after || "") + 1), sliceBegins);
        }
        if (paginated?.last) {
            sliceEnds = Math.min(paginated?.last, sliceEnds);
        }
        else if (paginated?.before) {
            sliceEnds = Math.min(allLinkTags.indexOf(paginated?.before || ""), sliceEnds);
        }
        const paginatedLinks = dedupedLinks.slice(sliceBegins, sliceEnds);
        const entries = await getEntries(cell, paginatedLinks);
        return entries;
    }
    else {
        const entries = await getEntries(cell, dedupedLinks);
        return entries;
    }
}
export async function getEntries(cell, list) {
    // for each entry in the list, check the store, and if not found, fetch it
    let entries = [];
    let toFetch = [];
    list.forEach((link) => {
        const revisionId = encodeHashToBase64(link.target);
        let entry = getEntryFromStore(revisionId);
        if (entry) {
            entries.push(entry);
            // console.log("======================got entry from store=======================", entry)
        }
        else {
            toFetch.push(revisionId);
            // console.log("--------------------------fetching entry from zome---------------------", revisionId)
        }
    });
    if (toFetch.length > 0) {
        let entriesRes = await cell.callZome({
            zome_name: 'hrea',
            fn_name: 'get_generic_entries',
            payload: toFetch,
        });
        entriesRes.forEach((res) => {
            if (res?.entry?.Present) {
                const decoded = decode(res.entry.Present.entry);
                const camelCased = snakeToCamel(decoded);
                const withIds = {
                    ...camelCased,
                    // @ts-ignore
                    id: decoded?.id ? encodeHashToBase64(decoded.id) : encodeHashToBase64(res.signed_action.hashed.hash),
                    revisionId: encodeHashToBase64(res.signed_action.hashed.hash),
                    meta: {
                        retrievedRevision: {
                            id: encodeHashToBase64(res.signed_action.hashed.hash),
                            time: actionTimestamp(res.signed_action.hashed.content),
                        }
                    }
                };
                const withFormattedDates = formatDates(withIds);
                addEntryToStore(withIds.revisionId, withFormattedDates);
                updateLatestRevision(withFormattedDates.id, withFormattedDates);
                entries.push(withFormattedDates);
            }
            else {
                console.log(`No entry for items (${list})`, res);
            }
        });
    }
    return entries;
}
/**
 * Timestamp of a signed action, across the 0.6 and 0.7 action shapes.
 *
 * Holochain 0.7 splits an Action into `{ header, data }`: the fields every
 * variant shares (author, timestamp, action_seq, prev_action) moved under
 * `header`, and the variant payload under `data`. On 0.6 they sat flat on
 * `content`. Reading only the 0.7 path would break any consumer still on 0.6,
 * and reading only the 0.6 path is what made `meta.retrievedRevision.time`
 * come back empty on 0.7.
 */
export function actionTimestamp(content) {
    return content?.header?.timestamp ?? content?.timestamp;
}
export function formatResItem(resItem, id) {
    if (!resItem?.entry?.Present?.entry) {
        return null;
    }
    let decoded = decode(resItem.entry.Present.entry);
    let camel = snakeToCamel(decoded);
    let withId = {
        ...camel,
        id: id,
        revisionId: encodeHashToBase64(resItem.signed_action.hashed.hash),
        meta: {
            retrievedRevision: {
                id: encodeHashToBase64(resItem.signed_action.hashed.hash),
                time: actionTimestamp(resItem.signed_action.hashed.content),
            }
        }
    };
    let encoded = formatDates(withId);
    return encoded;
}
export function snakeToCamelString(str) {
    // convert a snake_case string to camelCase
    return str.replace(/_([a-z])/g, function (g) { return g[1].toUpperCase(); });
}
export function snakeToCamel(lib) {
    // Recursively convert all keys from snake_case to camelCase
    // Do not convert if it's a hash (object with only numeric keys)
    if (Array.isArray(lib)) {
        return lib.map(snakeToCamel);
    }
    else if (lib !== null && typeof lib === 'object') {
        // Check if all keys are numeric (hash object)
        const keys = Object.keys(lib);
        const allNumeric = keys.length > 0 && keys.every(k => /^\d+$/.test(k));
        if (allNumeric) {
            return lib;
        }
        let camel = {};
        for (let key in lib) {
            let camelKey = key.replace(/_([a-z])/g, function (g) { return g[1].toUpperCase(); });
            // convert rea_action
            if (camelKey === "reaAction") {
                camelKey = "action";
            }
            const value = lib[key];
            camel[camelKey] = (typeof value === 'object' && value !== null)
                ? snakeToCamel(value)
                : value;
        }
        return camel;
    }
    return lib;
}
export function camelToSnake(lib) {
    // Recursively convert all keys from camelCase to snake_case
    if (Array.isArray(lib)) {
        return lib.map(camelToSnake);
    }
    else if (lib !== null && typeof lib === 'object') {
        let snake = {};
        for (let key in lib) {
            let snakeKey = key.replace(/([A-Z])/g, "_$1").toLowerCase();
            // convert action
            if (snakeKey === "action") {
                snakeKey = "rea_action";
            }
            // turn null values into undefined
            let value = lib[key] === null ? undefined : lib[key];
            // recursively convert objects and arrays
            if (typeof value === 'object' && value !== null) {
                value = camelToSnake(value);
            }
            snake[snakeKey] = value;
        }
        return snake;
    }
    return lib;
}
export function detectQuantityValueField(field) {
    if (field.has_numerical_value !== undefined && field.has_unit !== undefined) {
        return true;
    }
    return false;
}
export function decodePotentialQuantityValueField(field) {
    if (field.hasNumericalValue !== undefined && field.hasUnit !== undefined) {
        return {
            has_numerical_value: field.hasNumericalValue,
            has_unit: field.hasUnit?.id ? field.hasUnit.id : (field.hasUnit ? field.hasUnit : null)
        };
    }
    return field;
}
export function findAndDecodeQuantityValueFields(obj) {
    for (let key in obj) {
        if (typeof obj[key] === 'object' && obj[key] !== null) {
            if (obj[key].hasNumericalValue !== undefined && obj[key].hasUnit !== undefined) {
                obj[key] = decodePotentialQuantityValueField(obj[key]);
            }
        }
    }
    return obj;
}
// const dateFields = ['due', 'hasBeginning', 'hasEnd', 'hasPointInTime']
// export function formatDates(obj: any) {
//   dateFields.forEach(field => {
//     if (obj[field]) {
//       obj[field] = new Date(obj[field] / 1000)
//     }
//   })
//   return obj
// }
// export function reverseFormatDates(obj: any) {
//   dateFields.forEach(field => {
//     if (obj[field]) {
//       obj[field] = new Date(obj[field]).getTime() * 1000
//     }
//   })
//   return obj
// }
const dateFields = ['due', 'hasBeginning', 'hasEnd', 'hasPointInTime'];
export function formatDates(obj) {
    dateFields.forEach(field => {
        if (obj[field]) {
            // Only convert if not already a Date
            if (!(obj[field] instanceof Date)) {
                // if it is a number, assume it's a timestamp
                if (typeof obj[field] === 'number') {
                    obj[field] = new Date(obj[field] / 1000);
                }
                else if (typeof obj[field] === 'string') {
                    // if it's a string, try to parse it as a date
                    const parsedDate = new Date(obj[field]);
                    if (!isNaN(parsedDate.getTime())) {
                        obj[field] = parsedDate;
                    }
                }
            }
        }
    });
    return obj;
}
export function reverseFormatDates(obj) {
    dateFields.forEach(field => {
        if (obj[field]) {
            // Only convert if not already a number (timestamp)
            if (obj[field] instanceof Date) {
                obj[field] = obj[field].getTime() * 1000;
            }
            else if (typeof obj[field] === 'string') {
                // if it's a string, try to parse it as a date
                const parsedDate = new Date(obj[field]);
                if (!isNaN(parsedDate.getTime())) {
                    obj[field] = parsedDate.getTime() * 1000;
                }
            }
        }
    });
    return obj;
}
export function pluralize(str) {
    if (str === 'person') {
        return 'people';
    }
    else if (str.endsWith('s')) {
        return str + 'es';
    }
    else if (str.endsWith('y')) {
        return str.slice(0, -1) + 'ies';
    }
    else if (str.endsWith('o')) {
        return str + 'es';
    }
    else if (str.endsWith('ch')) {
        return str + 'es';
    }
    else if (str.endsWith('sh')) {
        return str + 'es';
    }
    else {
        return str + 's';
    }
}
export function decodeHashFields(obj, hashFields) {
    hashFields.forEach(field => {
        if (obj[field]) {
            const decodedField = decodeHashFromBase64(obj[field]);
            obj[field] = decodedField;
            obj[`${field}Id`] = decodedField;
        }
    });
    return obj;
}
const actions = {
    "dropoff": {
        id: "dropoff",
        label: "dropoff",
        resourceEffect: "decrement",
        onhandEffect: "decrement",
        inputOutput: "output",
        pairsWith: "pickup"
    },
    "pickup": {
        id: "pickup",
        label: "pickup",
        resourceEffect: "increment",
        onhandEffect: "increment",
        inputOutput: "input",
        pairsWith: "dropoff"
    },
    "consume": {
        id: "consume",
        label: "consume",
        resourceEffect: "decrement",
        onhandEffect: "decrement",
        inputOutput: "input",
        pairsWith: "notApplicable"
    },
    "use": {
        id: "use",
        label: "use",
        resourceEffect: "noEffect",
        onhandEffect: "noEffect",
        inputOutput: "input",
        pairsWith: "notApplicable"
    },
    "work": {
        id: "work",
        label: "work",
        resourceEffect: "noEffect",
        onhandEffect: "noEffect",
        inputOutput: "input",
        pairsWith: "notApplicable"
    },
    "cite": {
        id: "cite",
        label: "cite",
        resourceEffect: "noEffect",
        onhandEffect: "noEffect",
        inputOutput: "input",
        pairsWith: "notApplicable"
    },
    "produce": {
        id: "produce",
        label: "produce",
        resourceEffect: "increment",
        onhandEffect: "increment",
        inputOutput: "output",
        pairsWith: "notApplicable"
    },
    "accept": {
        id: "accept",
        label: "accept",
        resourceEffect: "noEffect",
        onhandEffect: "decrement",
        inputOutput: "input",
        pairsWith: "modify"
    },
    "modify": {
        id: "modify",
        label: "modify",
        resourceEffect: "noEffect",
        onhandEffect: "increment",
        inputOutput: "output",
        pairsWith: "accept"
    },
    "pass": {
        id: "pass",
        label: "pass",
        resourceEffect: "noEffect",
        onhandEffect: "noEffect",
        inputOutput: "output",
        pairsWith: "accept"
    },
    "fail": {
        id: "fail",
        label: "fail",
        resourceEffect: "noEffect",
        onhandEffect: "noEffect",
        inputOutput: "output",
        pairsWith: "accept"
    },
    "combine": {
        id: "combine",
        label: "combine",
        resourceEffect: "noEffect",
        onhandEffect: "decrement",
        inputOutput: "input",
        pairsWith: "notApplicable"
    },
    "separate": {
        id: "separate",
        label: "separate",
        resourceEffect: "noEffect",
        onhandEffect: "increment",
        inputOutput: "output",
        pairsWith: "notApplicable"
    },
    "copy": {
        id: "copy",
        label: "copy",
        resourceEffect: "increment",
        onhandEffect: "increment",
        inputOutput: "notApplicable",
        pairsWith: "notApplicable"
    },
    "deliver-service": {
        id: "deliver-service",
        label: "deliver-service",
        resourceEffect: "noEffect",
        onhandEffect: "noEffect",
        inputOutput: "output",
        pairsWith: "notApplicable"
    },
    "transfer-all-rights": {
        id: "transfer-all-rights",
        label: "transfer-all-rights",
        resourceEffect: "decrementIncrement",
        onhandEffect: "noEffect",
        inputOutput: "notApplicable",
        pairsWith: "notApplicable"
    },
    "transfer-custody": {
        id: "transfer-custody",
        label: "transfer-custody",
        resourceEffect: "noEffect",
        onhandEffect: "decrementIncrement",
        inputOutput: "notApplicable",
        pairsWith: "notApplicable"
    },
    "transfer": {
        id: "transfer",
        label: "transfer",
        resourceEffect: "decrementIncrement",
        onhandEffect: "decrementIncrement",
        inputOutput: "notApplicable",
        pairsWith: "notApplicable"
    },
    "move": {
        id: "move",
        label: "move",
        resourceEffect: "decrementIncrement",
        onhandEffect: "decrementIncrement",
        inputOutput: "notApplicable",
        pairsWith: "notApplicable"
    },
    "raise": {
        id: "raise",
        label: "raise",
        resourceEffect: "increment",
        onhandEffect: "increment",
        inputOutput: "notApplicable",
        pairsWith: "notApplicable"
    },
    "lower": {
        id: "lower",
        label: "lower",
        resourceEffect: "decrement",
        onhandEffect: "decrement",
        inputOutput: "notApplicable",
        pairsWith: "notApplicable"
    }
};
export function getAction(id) {
    return actions[id];
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXRpbC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy91dGlsLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxNQUFNLEVBQVUsTUFBTSxrQkFBa0IsQ0FBQztBQUNsRCxPQUFPLEVBQUUsb0JBQW9CLEVBQUUsa0JBQWtCLEVBQThCLE1BQU0sbUJBQW1CLENBQUE7QUFFeEcsT0FBTyxFQUFFLGlCQUFpQixFQUFFLGVBQWUsRUFBRSxvQkFBb0IsRUFBRSxNQUFNLFlBQVksQ0FBQztBQWN0RixNQUFNLFVBQVUsVUFBVSxDQUFDLEdBQW9CO0lBQzdDLGtDQUFrQztJQUNsQyxJQUFJLEVBQUUsR0FBRyxHQUFHLENBQUMsRUFBRSxDQUFBO0lBQ2YsSUFBSSxVQUFVLEdBQUcsR0FBRyxDQUFDLFVBQVUsQ0FBQTtJQUMvQixJQUFJLE1BQU0sR0FBRyxFQUFDLEVBQUUsRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBQyxDQUFBO0lBQ3hDLElBQUksSUFBSSxHQUFHLEVBQUUsR0FBRyxHQUFHLEVBQXlCLENBQUE7SUFDNUMsT0FBTyxJQUFJLENBQUMsRUFBRSxDQUFBO0lBQ2QsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFBO0lBQ3RCLE1BQU0sQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFBO0lBQ25CLE9BQU8sTUFBTSxDQUFBO0FBQ2YsQ0FBQztBQUVELE1BQU0sQ0FBQyxLQUFLLFVBQVUsc0JBQXNCLENBQUMsSUFBUyxFQUFFLFFBQWdCLEVBQUUsU0FBaUIsRUFBRSxTQUF1QjtJQUNsSCxNQUFNLFVBQVUsR0FBRyxNQUFNLGFBQWEsQ0FBQyxJQUFJLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQztJQUN4RSxNQUFNLG1CQUFtQixHQUFHLGtCQUFrQixDQUFDLFVBQVUsRUFBRSxTQUFTLENBQUMsQ0FBQztJQUN0RSxPQUFPLG1CQUFtQixDQUFBO0FBQzVCLENBQUM7QUFFRCxNQUFNLFVBQVUsa0JBQWtCLENBQUMsVUFBZSxFQUFFLElBQWtCO0lBQ3BFLE1BQU0sU0FBUyxHQUFHLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFTLEVBQUUsRUFBRTtRQUMzQyxPQUFPO1lBQ0gsVUFBVSxFQUFFLFdBQVc7WUFDdkIsTUFBTSxFQUFFLElBQUksQ0FBQyxFQUFFO1lBQ2YsSUFBSSxFQUFFO2dCQUNGLEdBQUcsSUFBSTtnQkFDUCxVQUFVLEVBQUUsSUFBSSxDQUFDLFNBQVM7YUFDN0I7U0FDSixDQUFBO0lBQ0wsQ0FBQyxDQUFDLENBQUE7SUFDRixPQUFPO1FBQ0gsUUFBUSxFQUFFO1lBQ04sU0FBUyxFQUFFLElBQUk7WUFDZixXQUFXLEVBQUUsS0FBSztZQUNsQixlQUFlLEVBQUUsS0FBSztZQUN0QixTQUFTLEVBQUUsSUFBSTtZQUNmLFdBQVcsRUFBRSxJQUFJO1lBQ2pCLFVBQVUsRUFBRSxJQUFJO1NBQ25CO1FBQ0QsS0FBSyxFQUFFLFNBQVM7S0FDbkIsQ0FBQTtBQUNILENBQUM7QUFFRCxNQUFNLENBQUMsS0FBSyxVQUFVLGtCQUFrQixDQUN0QyxJQUFTLEVBQ1QsUUFBZ0IsRUFDaEIsT0FBWSxFQUNaLFNBQXdCO0lBRXRCLE1BQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDLFFBQVEsQ0FBQztRQUMvQixTQUFTLEVBQUUsTUFBTTtRQUNqQixPQUFPLEVBQUUsUUFBUTtRQUNqQixPQUFPO0tBQ1YsQ0FBQyxDQUFBO0lBQ0YsTUFBTSxZQUFZLEdBQWdCLEtBQUssQ0FBQyxJQUFJLENBQ3hDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFzQixFQUFFLElBQVUsRUFBRSxFQUFFO1FBQ2pELE1BQU0sYUFBYSxHQUFHLGtCQUFrQixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNuRCxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEVBQUUsU0FBUyxJQUFJLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUN2RixHQUFHLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNqQyxDQUFDO1FBQ0QsT0FBTyxHQUFHLENBQUM7SUFDZixDQUFDLEVBQUUsSUFBSSxHQUFHLEVBQUUsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUN6QixDQUFDO0lBQ0YsT0FBTyxZQUFZLENBQUE7QUFDdkIsQ0FBQztBQUVELE1BQU0sQ0FBQyxLQUFLLFVBQVUsYUFBYSxDQUNqQyxJQUFTLEVBQ1QsUUFBZ0IsRUFDaEIsT0FBWSxFQUNaLFNBQXdCO0lBRXRCLE1BQU0sWUFBWSxHQUFHLE1BQU0sa0JBQWtCLENBQUMsSUFBSSxFQUFFLFFBQVEsRUFBRSxPQUFPLEVBQUUsU0FBUyxDQUFDLENBQUM7SUFFbEYsb0JBQW9CO0lBQ3BCLElBQUksU0FBUyxFQUFFLENBQUM7UUFDZCxNQUFNLFdBQVcsR0FBRyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBVSxFQUFFLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQTtRQUNsRixJQUFJLFdBQVcsR0FBRyxDQUFDLENBQUE7UUFDbkIsSUFBSSxTQUFTLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQTtRQUNuQyxJQUFJLFNBQVMsRUFBRSxLQUFLLEVBQUUsQ0FBQztZQUNyQixXQUFXLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsS0FBSyxHQUFHLENBQUMsRUFBRSxXQUFXLENBQUMsQ0FBQTtRQUMzRCxDQUFDO2FBQU0sSUFBSSxTQUFTLEVBQUUsS0FBSyxFQUFFLENBQUM7WUFDNUIsV0FBVyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxLQUFLLElBQUksRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsV0FBVyxDQUFDLENBQUE7UUFDeEYsQ0FBQztRQUNELElBQUksU0FBUyxFQUFFLElBQUksRUFBRSxDQUFDO1lBQ3BCLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxJQUFJLEVBQUUsU0FBUyxDQUFDLENBQUE7UUFDbEQsQ0FBQzthQUFNLElBQUksU0FBUyxFQUFFLE1BQU0sRUFBRSxDQUFDO1lBQzdCLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLE1BQU0sSUFBSSxFQUFFLENBQUMsRUFBRSxTQUFTLENBQUMsQ0FBQTtRQUMvRSxDQUFDO1FBRUQsTUFBTSxjQUFjLEdBQUcsWUFBWSxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUUsU0FBUyxDQUFDLENBQUE7UUFDakUsTUFBTSxPQUFPLEdBQUcsTUFBTSxVQUFVLENBQUMsSUFBSSxFQUFFLGNBQWMsQ0FBQyxDQUFDO1FBQ3ZELE9BQU8sT0FBTyxDQUFBO0lBQ2hCLENBQUM7U0FBTSxDQUFDO1FBQ04sTUFBTSxPQUFPLEdBQUcsTUFBTSxVQUFVLENBQUMsSUFBSSxFQUFFLFlBQVksQ0FBQyxDQUFDO1FBQ3JELE9BQU8sT0FBTyxDQUFBO0lBQ2hCLENBQUM7QUFDTCxDQUFDO0FBRUQsTUFBTSxDQUFDLEtBQUssVUFBVSxVQUFVLENBQUMsSUFBUyxFQUFFLElBQVk7SUFDdEQsMEVBQTBFO0lBQzFFLElBQUksT0FBTyxHQUFVLEVBQUUsQ0FBQTtJQUN2QixJQUFJLE9BQU8sR0FBYSxFQUFFLENBQUE7SUFFMUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFO1FBQ3BCLE1BQU0sVUFBVSxHQUFHLGtCQUFrQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQTtRQUNsRCxJQUFJLEtBQUssR0FBRyxpQkFBaUIsQ0FBQyxVQUFVLENBQUMsQ0FBQTtRQUN6QyxJQUFJLEtBQUssRUFBRSxDQUFDO1lBQ1YsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQTtZQUNuQiwwRkFBMEY7UUFDNUYsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFBO1lBQ3hCLHFHQUFxRztRQUN2RyxDQUFDO0lBQ0gsQ0FBQyxDQUFDLENBQUE7SUFFRixJQUFJLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7UUFDdkIsSUFBSSxVQUFVLEdBQUcsTUFBTSxJQUFJLENBQUMsUUFBUSxDQUFDO1lBQ25DLFNBQVMsRUFBRSxNQUFNO1lBQ2pCLE9BQU8sRUFBRSxxQkFBcUI7WUFDOUIsT0FBTyxFQUFFLE9BQU87U0FDakIsQ0FBQyxDQUFBO1FBRUYsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQVEsRUFBRSxFQUFFO1lBQzlCLElBQUksR0FBRyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsQ0FBQztnQkFDeEIsTUFBTSxPQUFPLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFBO2dCQUMvQyxNQUFNLFVBQVUsR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUE7Z0JBQ3hDLE1BQU0sT0FBTyxHQUFHO29CQUNkLEdBQUcsVUFBVTtvQkFDYixhQUFhO29CQUNiLEVBQUUsRUFBRSxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztvQkFDcEcsVUFBVSxFQUFFLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztvQkFDN0QsSUFBSSxFQUFFO3dCQUNKLGlCQUFpQixFQUFFOzRCQUNqQixFQUFFLEVBQUUsa0JBQWtCLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDOzRCQUNyRCxJQUFJLEVBQUUsZUFBZSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzt5QkFDeEQ7cUJBQ0Y7aUJBQ0YsQ0FBQTtnQkFDRCxNQUFNLGtCQUFrQixHQUFHLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQTtnQkFDL0MsZUFBZSxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsa0JBQWtCLENBQUMsQ0FBQTtnQkFDdkQsb0JBQW9CLENBQ2xCLGtCQUFrQixDQUFDLEVBQUUsRUFDckIsa0JBQWtCLENBQ25CLENBQUE7Z0JBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFBO1lBQ2xDLENBQUM7aUJBQU0sQ0FBQztnQkFDTixPQUFPLENBQUMsR0FBRyxDQUFDLHVCQUF1QixJQUFJLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQTtZQUNsRCxDQUFDO1FBQ0gsQ0FBQyxDQUFDLENBQUE7SUFDSixDQUFDO0lBQ0QsT0FBTyxPQUFPLENBQUE7QUFDaEIsQ0FBQztBQUVEOzs7Ozs7Ozs7R0FTRztBQUNILE1BQU0sVUFBVSxlQUFlLENBQUMsT0FBWTtJQUMxQyxPQUFPLE9BQU8sRUFBRSxNQUFNLEVBQUUsU0FBUyxJQUFJLE9BQU8sRUFBRSxTQUFTLENBQUE7QUFDekQsQ0FBQztBQUVELE1BQU0sVUFBVSxhQUFhLENBQUMsT0FBWSxFQUFFLEVBQVU7SUFDcEQsSUFBSSxDQUFDLE9BQU8sRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxDQUFDO1FBQUMsT0FBTyxJQUFJLENBQUE7SUFBQyxDQUFDO0lBQ3BELElBQUksT0FBTyxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQTtJQUNqRCxJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUE7SUFDakMsSUFBSSxNQUFNLEdBQUc7UUFDWCxHQUFHLEtBQUs7UUFDUixFQUFFLEVBQUcsRUFBRTtRQUNQLFVBQVUsRUFBRSxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7UUFDakUsSUFBSSxFQUFFO1lBQ0osaUJBQWlCLEVBQUU7Z0JBQ2pCLEVBQUUsRUFBRSxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7Z0JBQ3pELElBQUksRUFBRSxlQUFlLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO2FBQzVEO1NBQ0Y7S0FDRixDQUFBO0lBQ0QsSUFBSSxPQUFPLEdBQUcsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFBO0lBQ2pDLE9BQU8sT0FBTyxDQUFBO0FBQ2hCLENBQUM7QUFFRCxNQUFNLFVBQVUsa0JBQWtCLENBQUMsR0FBVztJQUM1QywyQ0FBMkM7SUFDM0MsT0FBTyxHQUFHLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxVQUFVLENBQUMsSUFBSSxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9FLENBQUM7QUFFRCxNQUFNLFVBQVUsWUFBWSxDQUFDLEdBQVE7SUFDbkMsNERBQTREO0lBQzVELGdFQUFnRTtJQUNoRSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztRQUN2QixPQUFPLEdBQUcsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDL0IsQ0FBQztTQUFNLElBQUksR0FBRyxLQUFLLElBQUksSUFBSSxPQUFPLEdBQUcsS0FBSyxRQUFRLEVBQUUsQ0FBQztRQUNuRCw4Q0FBOEM7UUFDOUMsTUFBTSxJQUFJLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUM5QixNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3ZFLElBQUksVUFBVSxFQUFFLENBQUM7WUFDZixPQUFPLEdBQUcsQ0FBQztRQUNiLENBQUM7UUFDRCxJQUFJLEtBQUssR0FBUSxFQUFFLENBQUM7UUFDcEIsS0FBSyxJQUFJLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQztZQUNwQixJQUFJLFFBQVEsR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxVQUFVLENBQUMsSUFBSSxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3JGLHFCQUFxQjtZQUNyQixJQUFJLFFBQVEsS0FBSyxXQUFXLEVBQUUsQ0FBQztnQkFDN0IsUUFBUSxHQUFHLFFBQVEsQ0FBQztZQUN0QixDQUFDO1lBQ0QsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3ZCLEtBQUssQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLE9BQU8sS0FBSyxLQUFLLFFBQVEsSUFBSSxLQUFLLEtBQUssSUFBSSxDQUFDO2dCQUM3RCxDQUFDLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQztnQkFDckIsQ0FBQyxDQUFDLEtBQUssQ0FBQztRQUNaLENBQUM7UUFDRCxPQUFPLEtBQUssQ0FBQztJQUNmLENBQUM7SUFDRCxPQUFPLEdBQUcsQ0FBQztBQUNiLENBQUM7QUFFRCxNQUFNLFVBQVUsWUFBWSxDQUFDLEdBQVE7SUFDbkMsNERBQTREO0lBQzVELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO1FBQ3ZCLE9BQU8sR0FBRyxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUMvQixDQUFDO1NBQU0sSUFBSSxHQUFHLEtBQUssSUFBSSxJQUFJLE9BQU8sR0FBRyxLQUFLLFFBQVEsRUFBRSxDQUFDO1FBQ25ELElBQUksS0FBSyxHQUFRLEVBQUUsQ0FBQztRQUNwQixLQUFLLElBQUksR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO1lBQ3BCLElBQUksUUFBUSxHQUFHLEdBQUcsQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQzVELGlCQUFpQjtZQUNqQixJQUFJLFFBQVEsS0FBSyxRQUFRLEVBQUUsQ0FBQztnQkFDMUIsUUFBUSxHQUFHLFlBQVksQ0FBQztZQUMxQixDQUFDO1lBQ0Qsa0NBQWtDO1lBQ2xDLElBQUksS0FBSyxHQUFHLEdBQUcsQ0FBQyxHQUFHLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3JELHlDQUF5QztZQUN6QyxJQUFJLE9BQU8sS0FBSyxLQUFLLFFBQVEsSUFBSSxLQUFLLEtBQUssSUFBSSxFQUFFLENBQUM7Z0JBQ2hELEtBQUssR0FBRyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDOUIsQ0FBQztZQUNELEtBQUssQ0FBQyxRQUFRLENBQUMsR0FBRyxLQUFLLENBQUM7UUFDMUIsQ0FBQztRQUNELE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQztJQUNELE9BQU8sR0FBRyxDQUFDO0FBQ2IsQ0FBQztBQUVELE1BQU0sVUFBVSx3QkFBd0IsQ0FBQyxLQUFVO0lBQ2pELElBQUksS0FBSyxDQUFDLG1CQUFtQixLQUFLLFNBQVMsSUFBSSxLQUFLLENBQUMsUUFBUSxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQzVFLE9BQU8sSUFBSSxDQUFBO0lBQ2IsQ0FBQztJQUNELE9BQU8sS0FBSyxDQUFBO0FBQ2QsQ0FBQztBQUVELE1BQU0sVUFBVSxpQ0FBaUMsQ0FBQyxLQUFVO0lBQzFELElBQUksS0FBSyxDQUFDLGlCQUFpQixLQUFLLFNBQVMsSUFBSSxLQUFLLENBQUMsT0FBTyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQ3pFLE9BQU87WUFDTCxtQkFBbUIsRUFBRSxLQUFLLENBQUMsaUJBQWlCO1lBQzVDLFFBQVEsRUFBRSxLQUFLLENBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1NBQ3hGLENBQUE7SUFDSCxDQUFDO0lBQ0QsT0FBTyxLQUFLLENBQUE7QUFDZCxDQUFDO0FBRUQsTUFBTSxVQUFVLGdDQUFnQyxDQUFDLEdBQVE7SUFDdkQsS0FBSyxJQUFJLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUNwQixJQUFJLE9BQU8sR0FBRyxDQUFDLEdBQUcsQ0FBQyxLQUFLLFFBQVEsSUFBSSxHQUFHLENBQUMsR0FBRyxDQUFDLEtBQUssSUFBSSxFQUFFLENBQUM7WUFDdEQsSUFBSSxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsaUJBQWlCLEtBQUssU0FBUyxJQUFJLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLEtBQUssU0FBUyxFQUFFLENBQUM7Z0JBQy9FLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxpQ0FBaUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQTtZQUN4RCxDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFDRCxPQUFPLEdBQUcsQ0FBQTtBQUNaLENBQUM7QUFFRCx5RUFBeUU7QUFDekUsMENBQTBDO0FBQzFDLGtDQUFrQztBQUNsQyx3QkFBd0I7QUFDeEIsaURBQWlEO0FBQ2pELFFBQVE7QUFDUixPQUFPO0FBQ1AsZUFBZTtBQUNmLElBQUk7QUFFSixpREFBaUQ7QUFDakQsa0NBQWtDO0FBQ2xDLHdCQUF3QjtBQUN4QiwyREFBMkQ7QUFDM0QsUUFBUTtBQUNSLE9BQU87QUFDUCxlQUFlO0FBQ2YsSUFBSTtBQUNKLE1BQU0sVUFBVSxHQUFHLENBQUMsS0FBSyxFQUFFLGNBQWMsRUFBRSxRQUFRLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQTtBQUN0RSxNQUFNLFVBQVUsV0FBVyxDQUFDLEdBQVE7SUFDbEMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTtRQUN6QixJQUFJLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQ2YscUNBQXFDO1lBQ3JDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxJQUFJLENBQUMsRUFBRSxDQUFDO2dCQUNsQyw2Q0FBNkM7Z0JBQzdDLElBQUksT0FBTyxHQUFHLENBQUMsS0FBSyxDQUFDLEtBQUssUUFBUSxFQUFFLENBQUM7b0JBQ25DLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUE7Z0JBQzFDLENBQUM7cUJBQU0sSUFBSSxPQUFPLEdBQUcsQ0FBQyxLQUFLLENBQUMsS0FBSyxRQUFRLEVBQUUsQ0FBQztvQkFDMUMsOENBQThDO29CQUM5QyxNQUFNLFVBQVUsR0FBRyxJQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQTtvQkFDdkMsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDO3dCQUNqQyxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsVUFBVSxDQUFBO29CQUN6QixDQUFDO2dCQUNILENBQUM7WUFDSCxDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUMsQ0FBQyxDQUFBO0lBQ0YsT0FBTyxHQUFHLENBQUE7QUFDWixDQUFDO0FBRUQsTUFBTSxVQUFVLGtCQUFrQixDQUFDLEdBQVE7SUFDekMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTtRQUN6QixJQUFJLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQ2YsbURBQW1EO1lBQ25ELElBQUksR0FBRyxDQUFDLEtBQUssQ0FBQyxZQUFZLElBQUksRUFBRSxDQUFDO2dCQUMvQixHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sRUFBRSxHQUFHLElBQUksQ0FBQTtZQUMxQyxDQUFDO2lCQUFNLElBQUksT0FBTyxHQUFHLENBQUMsS0FBSyxDQUFDLEtBQUssUUFBUSxFQUFFLENBQUM7Z0JBQzFDLDhDQUE4QztnQkFDOUMsTUFBTSxVQUFVLEdBQUcsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUE7Z0JBQ3ZDLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxDQUFDLEVBQUUsQ0FBQztvQkFDakMsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLFVBQVUsQ0FBQyxPQUFPLEVBQUUsR0FBRyxJQUFJLENBQUE7Z0JBQzFDLENBQUM7WUFDSCxDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUMsQ0FBQyxDQUFBO0lBQ0YsT0FBTyxHQUFHLENBQUE7QUFDWixDQUFDO0FBRUQsTUFBTSxVQUFVLFNBQVMsQ0FBQyxHQUFXO0lBQ25DLElBQUksR0FBRyxLQUFLLFFBQVEsRUFBRSxDQUFDO1FBQ3JCLE9BQU8sUUFBUSxDQUFBO0lBQ2pCLENBQUM7U0FBTSxJQUFJLEdBQUcsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztRQUM3QixPQUFPLEdBQUcsR0FBRyxJQUFJLENBQUE7SUFDbkIsQ0FBQztTQUFNLElBQUksR0FBRyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO1FBQzdCLE9BQU8sR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxLQUFLLENBQUE7SUFDakMsQ0FBQztTQUFNLElBQUksR0FBRyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO1FBQzdCLE9BQU8sR0FBRyxHQUFHLElBQUksQ0FBQTtJQUNuQixDQUFDO1NBQU0sSUFBSSxHQUFHLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7UUFDOUIsT0FBTyxHQUFHLEdBQUcsSUFBSSxDQUFBO0lBQ25CLENBQUM7U0FBTSxJQUFJLEdBQUcsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztRQUM5QixPQUFPLEdBQUcsR0FBRyxJQUFJLENBQUE7SUFDbkIsQ0FBQztTQUFNLENBQUM7UUFDTixPQUFPLEdBQUcsR0FBRyxHQUFHLENBQUE7SUFDbEIsQ0FBQztBQUNILENBQUM7QUFFRCxNQUFNLFVBQVUsZ0JBQWdCLENBQUMsR0FBUSxFQUFFLFVBQW9CO0lBQzdELFVBQVUsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUU7UUFDekIsSUFBSSxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUNmLE1BQU0sWUFBWSxHQUFHLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFBO1lBQ3JELEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxZQUFZLENBQUE7WUFDekIsR0FBRyxDQUFDLEdBQUcsS0FBSyxJQUFJLENBQUMsR0FBRyxZQUFZLENBQUE7UUFDbEMsQ0FBQztJQUNILENBQUMsQ0FBQyxDQUFBO0lBQ0YsT0FBTyxHQUFHLENBQUE7QUFDWixDQUFDO0FBRUQsTUFBTSxPQUFPLEdBQUc7SUFDZCxTQUFTLEVBQUU7UUFDVCxFQUFFLEVBQUUsU0FBUztRQUNiLEtBQUssRUFBRSxTQUFTO1FBQ2hCLGNBQWMsRUFBRSxXQUFXO1FBQzNCLFlBQVksRUFBRSxXQUFXO1FBQ3pCLFdBQVcsRUFBRSxRQUFRO1FBQ3JCLFNBQVMsRUFBRSxRQUFRO0tBQ3BCO0lBQ0QsUUFBUSxFQUFFO1FBQ1IsRUFBRSxFQUFFLFFBQVE7UUFDWixLQUFLLEVBQUUsUUFBUTtRQUNmLGNBQWMsRUFBRSxXQUFXO1FBQzNCLFlBQVksRUFBRSxXQUFXO1FBQ3pCLFdBQVcsRUFBRSxPQUFPO1FBQ3BCLFNBQVMsRUFBRSxTQUFTO0tBQ3JCO0lBQ0QsU0FBUyxFQUFFO1FBQ1QsRUFBRSxFQUFFLFNBQVM7UUFDYixLQUFLLEVBQUUsU0FBUztRQUNoQixjQUFjLEVBQUUsV0FBVztRQUMzQixZQUFZLEVBQUUsV0FBVztRQUN6QixXQUFXLEVBQUUsT0FBTztRQUNwQixTQUFTLEVBQUUsZUFBZTtLQUMzQjtJQUNELEtBQUssRUFBRTtRQUNMLEVBQUUsRUFBRSxLQUFLO1FBQ1QsS0FBSyxFQUFFLEtBQUs7UUFDWixjQUFjLEVBQUUsVUFBVTtRQUMxQixZQUFZLEVBQUUsVUFBVTtRQUN4QixXQUFXLEVBQUUsT0FBTztRQUNwQixTQUFTLEVBQUUsZUFBZTtLQUMzQjtJQUNELE1BQU0sRUFBRTtRQUNOLEVBQUUsRUFBRSxNQUFNO1FBQ1YsS0FBSyxFQUFFLE1BQU07UUFDYixjQUFjLEVBQUUsVUFBVTtRQUMxQixZQUFZLEVBQUUsVUFBVTtRQUN4QixXQUFXLEVBQUUsT0FBTztRQUNwQixTQUFTLEVBQUUsZUFBZTtLQUMzQjtJQUNELE1BQU0sRUFBRTtRQUNOLEVBQUUsRUFBRSxNQUFNO1FBQ1YsS0FBSyxFQUFFLE1BQU07UUFDYixjQUFjLEVBQUUsVUFBVTtRQUMxQixZQUFZLEVBQUUsVUFBVTtRQUN4QixXQUFXLEVBQUUsT0FBTztRQUNwQixTQUFTLEVBQUUsZUFBZTtLQUMzQjtJQUNELFNBQVMsRUFBRTtRQUNULEVBQUUsRUFBRSxTQUFTO1FBQ2IsS0FBSyxFQUFFLFNBQVM7UUFDaEIsY0FBYyxFQUFFLFdBQVc7UUFDM0IsWUFBWSxFQUFFLFdBQVc7UUFDekIsV0FBVyxFQUFFLFFBQVE7UUFDckIsU0FBUyxFQUFFLGVBQWU7S0FDM0I7SUFDRCxRQUFRLEVBQUU7UUFDUixFQUFFLEVBQUUsUUFBUTtRQUNaLEtBQUssRUFBRSxRQUFRO1FBQ2YsY0FBYyxFQUFFLFVBQVU7UUFDMUIsWUFBWSxFQUFFLFdBQVc7UUFDekIsV0FBVyxFQUFFLE9BQU87UUFDcEIsU0FBUyxFQUFFLFFBQVE7S0FDcEI7SUFDRCxRQUFRLEVBQUU7UUFDUixFQUFFLEVBQUUsUUFBUTtRQUNaLEtBQUssRUFBRSxRQUFRO1FBQ2YsY0FBYyxFQUFFLFVBQVU7UUFDMUIsWUFBWSxFQUFFLFdBQVc7UUFDekIsV0FBVyxFQUFFLFFBQVE7UUFDckIsU0FBUyxFQUFFLFFBQVE7S0FDcEI7SUFDRCxNQUFNLEVBQUU7UUFDTixFQUFFLEVBQUUsTUFBTTtRQUNWLEtBQUssRUFBRSxNQUFNO1FBQ2IsY0FBYyxFQUFFLFVBQVU7UUFDMUIsWUFBWSxFQUFFLFVBQVU7UUFDeEIsV0FBVyxFQUFFLFFBQVE7UUFDckIsU0FBUyxFQUFFLFFBQVE7S0FDcEI7SUFDRCxNQUFNLEVBQUU7UUFDTixFQUFFLEVBQUUsTUFBTTtRQUNWLEtBQUssRUFBRSxNQUFNO1FBQ2IsY0FBYyxFQUFFLFVBQVU7UUFDMUIsWUFBWSxFQUFFLFVBQVU7UUFDeEIsV0FBVyxFQUFFLFFBQVE7UUFDckIsU0FBUyxFQUFFLFFBQVE7S0FDcEI7SUFDRCxTQUFTLEVBQUU7UUFDVCxFQUFFLEVBQUUsU0FBUztRQUNiLEtBQUssRUFBRSxTQUFTO1FBQ2hCLGNBQWMsRUFBRSxVQUFVO1FBQzFCLFlBQVksRUFBRSxXQUFXO1FBQ3pCLFdBQVcsRUFBRSxPQUFPO1FBQ3BCLFNBQVMsRUFBRSxlQUFlO0tBQzNCO0lBQ0QsVUFBVSxFQUFFO1FBQ1YsRUFBRSxFQUFFLFVBQVU7UUFDZCxLQUFLLEVBQUUsVUFBVTtRQUNqQixjQUFjLEVBQUUsVUFBVTtRQUMxQixZQUFZLEVBQUUsV0FBVztRQUN6QixXQUFXLEVBQUUsUUFBUTtRQUNyQixTQUFTLEVBQUUsZUFBZTtLQUMzQjtJQUNELE1BQU0sRUFBRTtRQUNOLEVBQUUsRUFBRSxNQUFNO1FBQ1YsS0FBSyxFQUFFLE1BQU07UUFDYixjQUFjLEVBQUUsV0FBVztRQUMzQixZQUFZLEVBQUUsV0FBVztRQUN6QixXQUFXLEVBQUUsZUFBZTtRQUM1QixTQUFTLEVBQUUsZUFBZTtLQUMzQjtJQUNELGlCQUFpQixFQUFFO1FBQ2pCLEVBQUUsRUFBRSxpQkFBaUI7UUFDckIsS0FBSyxFQUFFLGlCQUFpQjtRQUN4QixjQUFjLEVBQUUsVUFBVTtRQUMxQixZQUFZLEVBQUUsVUFBVTtRQUN4QixXQUFXLEVBQUUsUUFBUTtRQUNyQixTQUFTLEVBQUUsZUFBZTtLQUMzQjtJQUNELHFCQUFxQixFQUFFO1FBQ3JCLEVBQUUsRUFBRSxxQkFBcUI7UUFDekIsS0FBSyxFQUFFLHFCQUFxQjtRQUM1QixjQUFjLEVBQUUsb0JBQW9CO1FBQ3BDLFlBQVksRUFBRSxVQUFVO1FBQ3hCLFdBQVcsRUFBRSxlQUFlO1FBQzVCLFNBQVMsRUFBRSxlQUFlO0tBQzNCO0lBQ0Qsa0JBQWtCLEVBQUU7UUFDbEIsRUFBRSxFQUFFLGtCQUFrQjtRQUN0QixLQUFLLEVBQUUsa0JBQWtCO1FBQ3pCLGNBQWMsRUFBRSxVQUFVO1FBQzFCLFlBQVksRUFBRSxvQkFBb0I7UUFDbEMsV0FBVyxFQUFFLGVBQWU7UUFDNUIsU0FBUyxFQUFFLGVBQWU7S0FDM0I7SUFDRCxVQUFVLEVBQUU7UUFDVixFQUFFLEVBQUUsVUFBVTtRQUNkLEtBQUssRUFBRSxVQUFVO1FBQ2pCLGNBQWMsRUFBRSxvQkFBb0I7UUFDcEMsWUFBWSxFQUFFLG9CQUFvQjtRQUNsQyxXQUFXLEVBQUUsZUFBZTtRQUM1QixTQUFTLEVBQUUsZUFBZTtLQUMzQjtJQUNELE1BQU0sRUFBRTtRQUNOLEVBQUUsRUFBRSxNQUFNO1FBQ1YsS0FBSyxFQUFFLE1BQU07UUFDYixjQUFjLEVBQUUsb0JBQW9CO1FBQ3BDLFlBQVksRUFBRSxvQkFBb0I7UUFDbEMsV0FBVyxFQUFFLGVBQWU7UUFDNUIsU0FBUyxFQUFFLGVBQWU7S0FDM0I7SUFDRCxPQUFPLEVBQUU7UUFDUCxFQUFFLEVBQUUsT0FBTztRQUNYLEtBQUssRUFBRSxPQUFPO1FBQ2QsY0FBYyxFQUFFLFdBQVc7UUFDM0IsWUFBWSxFQUFFLFdBQVc7UUFDekIsV0FBVyxFQUFFLGVBQWU7UUFDNUIsU0FBUyxFQUFFLGVBQWU7S0FDM0I7SUFDRCxPQUFPLEVBQUU7UUFDUCxFQUFFLEVBQUUsT0FBTztRQUNYLEtBQUssRUFBRSxPQUFPO1FBQ2QsY0FBYyxFQUFFLFdBQVc7UUFDM0IsWUFBWSxFQUFFLFdBQVc7UUFDekIsV0FBVyxFQUFFLGVBQWU7UUFDNUIsU0FBUyxFQUFFLGVBQWU7S0FDM0I7Q0FDRixDQUFBO0FBRUQsTUFBTSxVQUFVLFNBQVMsQ0FBQyxFQUFVO0lBQ2xDLE9BQU8sT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFBO0FBQ3BCLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBkZWNvZGUsIGVuY29kZSB9IGZyb20gJ0Btc2dwYWNrL21zZ3BhY2snO1xuaW1wb3J0IHsgZGVjb2RlSGFzaEZyb21CYXNlNjQsIGVuY29kZUhhc2hUb0Jhc2U2NCwgdHlwZSBBY3Rpb25IYXNoLCB0eXBlIExpbmsgfSBmcm9tICdAaG9sb2NoYWluL2NsaWVudCdcbmltcG9ydCB7IFBhZ2luZ1BhcmFtcyB9IGZyb20gJy4vdHlwZXMuanMnXG5pbXBvcnQgeyBnZXRFbnRyeUZyb21TdG9yZSwgYWRkRW50cnlUb1N0b3JlLCB1cGRhdGVMYXRlc3RSZXZpc2lvbiB9IGZyb20gJy4vc3RvcmUuanMnO1xuXG50eXBlIEV4dHJhY3RJZHNPdXRwdXQgPSB7XG4gIGlkOiBzdHJpbmc7XG4gIHJldmlzaW9uSWQ6IHN0cmluZztcbiAgZW50cnk6IGFueTtcbn1cblxudHlwZSBFeHRyYWN0SWRzSW5wdXQgPSB7XG4gIGlkOiBzdHJpbmc7XG4gIHJldmlzaW9uSWQ6IHN0cmluZztcbiAgW2tleTogc3RyaW5nXTogYW55O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZXh0cmFjdElkcyhvYmo6IEV4dHJhY3RJZHNJbnB1dCk6IEV4dHJhY3RJZHNPdXRwdXQge1xuICAvLyBleHRyYWN0IHRoZSBpZHMgZnJvbSB0aGUgb2JqZWN0XG4gIGxldCBpZCA9IG9iai5pZFxuICBsZXQgcmV2aXNpb25JZCA9IG9iai5yZXZpc2lvbklkXG4gIGxldCBvdXRwdXQgPSB7aWQsIHJldmlzaW9uSWQsIGVudHJ5OiB7fX1cbiAgbGV0IGFyZ3MgPSB7IC4uLm9iaiB9IGFzIFBhcnRpYWw8dHlwZW9mIG9iaj5cbiAgZGVsZXRlIGFyZ3MuaWRcbiAgZGVsZXRlIGFyZ3MucmV2aXNpb25JZFxuICBvdXRwdXQuZW50cnkgPSBhcmdzXG4gIHJldHVybiBvdXRwdXRcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFBhZ2luYXRlZENvbGxlY3Rpb24oY2VsbDogYW55LCBsaW5rRnVuYzogc3RyaW5nLCBlbnRyeUZ1bmM6IHN0cmluZywgcGFnaW5hdGVkOiBQYWdpbmdQYXJhbXMpIHtcbiAgY29uc3QgY29sbGVjdGlvbiA9IGF3YWl0IGdldENvbGxlY3Rpb24oY2VsbCwgbGlua0Z1bmMsIG51bGwsIHBhZ2luYXRlZCk7XG4gIGNvbnN0IHBhZ2luYXRlZENvbGxlY3Rpb24gPSBwYWdpbmF0ZUNvbGxlY3Rpb24oY29sbGVjdGlvbiwgcGFnaW5hdGVkKTtcbiAgcmV0dXJuIHBhZ2luYXRlZENvbGxlY3Rpb25cbn1cbiAgXG5leHBvcnQgZnVuY3Rpb24gcGFnaW5hdGVDb2xsZWN0aW9uKGNvbGxlY3Rpb246IGFueSwgYXJnczogUGFnaW5nUGFyYW1zKSB7XG4gIGNvbnN0IHBhZ2luYXRlZCA9IGNvbGxlY3Rpb24ubWFwKChpdGVtOiBhbnkpID0+IHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgICAgX190eXBlbmFtZTogJ0FnZW50RWRnZScsXG4gICAgICAgICAgY3Vyc29yOiBpdGVtLmlkLFxuICAgICAgICAgIG5vZGU6IHtcbiAgICAgICAgICAgICAgLi4uaXRlbSxcbiAgICAgICAgICAgICAgX190eXBlbmFtZTogaXRlbS5hZ2VudFR5cGVcbiAgICAgICAgICB9XG4gICAgICB9XG4gIH0pXG4gIHJldHVybiB7XG4gICAgICBwYWdlSW5mbzoge1xuICAgICAgICAgIGVuZEN1cnNvcjogbnVsbCxcbiAgICAgICAgICBoYXNOZXh0UGFnZTogZmFsc2UsXG4gICAgICAgICAgaGFzUHJldmlvdXNQYWdlOiBmYWxzZSxcbiAgICAgICAgICBwYWdlTGltaXQ6IG51bGwsXG4gICAgICAgICAgc3RhcnRDdXJzb3I6IG51bGwsXG4gICAgICAgICAgdG90YWxDb3VudDogbnVsbCxcbiAgICAgIH0sXG4gICAgICBlZGdlczogcGFnaW5hdGVkXG4gIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvbGxlY3Rpb25MaW5rcyhcbiAgY2VsbDogYW55LCBcbiAgbGlua0Z1bmM6IHN0cmluZywgXG4gIHBheWxvYWQ6IGFueSwgXG4gIHBhZ2luYXRlZD86IFBhZ2luZ1BhcmFtc1xuKSB7XG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY2VsbC5jYWxsWm9tZSh7XG4gICAgICAgIHpvbWVfbmFtZTogJ2hyZWEnLFxuICAgICAgICBmbl9uYW1lOiBsaW5rRnVuYyxcbiAgICAgICAgcGF5bG9hZCxcbiAgICB9KVxuICAgIGNvbnN0IGRlZHVwZWRMaW5rczogQXJyYXk8TGluaz4gPSBBcnJheS5mcm9tKFxuICAgICAgICByZXN1bHQucmVkdWNlKChtYXA6IE1hcDxzdHJpbmcsIExpbms+LCBsaW5rOiBMaW5rKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBlbmNvZGVkVGFyZ2V0ID0gZW5jb2RlSGFzaFRvQmFzZTY0KGxpbmsudGFnKTtcbiAgICAgICAgICAgIGlmICghbWFwLmhhcyhlbmNvZGVkVGFyZ2V0KSB8fCAobWFwLmdldChlbmNvZGVkVGFyZ2V0KT8udGltZXN0YW1wID8/IDApIDwgbGluay50aW1lc3RhbXApIHtcbiAgICAgICAgICAgICAgICBtYXAuc2V0KGVuY29kZWRUYXJnZXQsIGxpbmspO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG1hcDtcbiAgICAgICAgfSwgbmV3IE1hcCgpKS52YWx1ZXMoKVxuICAgICk7XG4gICAgcmV0dXJuIGRlZHVwZWRMaW5rc1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q29sbGVjdGlvbihcbiAgY2VsbDogYW55LCBcbiAgbGlua0Z1bmM6IHN0cmluZywgXG4gIHBheWxvYWQ6IGFueSwgXG4gIHBhZ2luYXRlZD86IFBhZ2luZ1BhcmFtc1xuKSB7XG4gICAgY29uc3QgZGVkdXBlZExpbmtzID0gYXdhaXQgZ2V0Q29sbGVjdGlvbkxpbmtzKGNlbGwsIGxpbmtGdW5jLCBwYXlsb2FkLCBwYWdpbmF0ZWQpO1xuXG4gICAgLy8gaGFuZGxlIHBhZ2luYXRpb25cbiAgICBpZiAocGFnaW5hdGVkKSB7XG4gICAgICBjb25zdCBhbGxMaW5rVGFncyA9IGRlZHVwZWRMaW5rcy5tYXAoKGxpbms6IExpbmspID0+IGVuY29kZUhhc2hUb0Jhc2U2NChsaW5rLnRhZykpXG4gICAgICBsZXQgc2xpY2VCZWdpbnMgPSAwXG4gICAgICBsZXQgc2xpY2VFbmRzID0gZGVkdXBlZExpbmtzLmxlbmd0aFxuICAgICAgaWYgKHBhZ2luYXRlZD8uZmlyc3QpIHtcbiAgICAgICAgc2xpY2VCZWdpbnMgPSBNYXRoLm1heChwYWdpbmF0ZWQ/LmZpcnN0IC0gMSwgc2xpY2VCZWdpbnMpXG4gICAgICB9IGVsc2UgaWYgKHBhZ2luYXRlZD8uYWZ0ZXIpIHtcbiAgICAgICAgc2xpY2VCZWdpbnMgPSBNYXRoLm1heCgoYWxsTGlua1RhZ3MuaW5kZXhPZihwYWdpbmF0ZWQ/LmFmdGVyIHx8IFwiXCIpICsgMSksIHNsaWNlQmVnaW5zKVxuICAgICAgfVxuICAgICAgaWYgKHBhZ2luYXRlZD8ubGFzdCkge1xuICAgICAgICBzbGljZUVuZHMgPSBNYXRoLm1pbihwYWdpbmF0ZWQ/Lmxhc3QsIHNsaWNlRW5kcylcbiAgICAgIH0gZWxzZSBpZiAocGFnaW5hdGVkPy5iZWZvcmUpIHtcbiAgICAgICAgc2xpY2VFbmRzID0gTWF0aC5taW4oYWxsTGlua1RhZ3MuaW5kZXhPZihwYWdpbmF0ZWQ/LmJlZm9yZSB8fCBcIlwiKSwgc2xpY2VFbmRzKVxuICAgICAgfVxuICAgICAgXG4gICAgICBjb25zdCBwYWdpbmF0ZWRMaW5rcyA9IGRlZHVwZWRMaW5rcy5zbGljZShzbGljZUJlZ2lucywgc2xpY2VFbmRzKVxuICAgICAgY29uc3QgZW50cmllcyA9IGF3YWl0IGdldEVudHJpZXMoY2VsbCwgcGFnaW5hdGVkTGlua3MpO1xuICAgICAgcmV0dXJuIGVudHJpZXNcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgZW50cmllcyA9IGF3YWl0IGdldEVudHJpZXMoY2VsbCwgZGVkdXBlZExpbmtzKTtcbiAgICAgIHJldHVybiBlbnRyaWVzXG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0RW50cmllcyhjZWxsOiBhbnksIGxpc3Q6IExpbmtbXSkge1xuICAvLyBmb3IgZWFjaCBlbnRyeSBpbiB0aGUgbGlzdCwgY2hlY2sgdGhlIHN0b3JlLCBhbmQgaWYgbm90IGZvdW5kLCBmZXRjaCBpdFxuICBsZXQgZW50cmllczogYW55W10gPSBbXVxuICBsZXQgdG9GZXRjaDogc3RyaW5nW10gPSBbXVxuXG4gIGxpc3QuZm9yRWFjaCgobGluaykgPT4ge1xuICAgIGNvbnN0IHJldmlzaW9uSWQgPSBlbmNvZGVIYXNoVG9CYXNlNjQobGluay50YXJnZXQpXG4gICAgbGV0IGVudHJ5ID0gZ2V0RW50cnlGcm9tU3RvcmUocmV2aXNpb25JZClcbiAgICBpZiAoZW50cnkpIHtcbiAgICAgIGVudHJpZXMucHVzaChlbnRyeSlcbiAgICAgIC8vIGNvbnNvbGUubG9nKFwiPT09PT09PT09PT09PT09PT09PT09PWdvdCBlbnRyeSBmcm9tIHN0b3JlPT09PT09PT09PT09PT09PT09PT09PT1cIiwgZW50cnkpXG4gICAgfSBlbHNlIHtcbiAgICAgIHRvRmV0Y2gucHVzaChyZXZpc2lvbklkKVxuICAgICAgLy8gY29uc29sZS5sb2coXCItLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLWZldGNoaW5nIGVudHJ5IGZyb20gem9tZS0tLS0tLS0tLS0tLS0tLS0tLS0tLVwiLCByZXZpc2lvbklkKVxuICAgIH1cbiAgfSlcblxuICBpZiAodG9GZXRjaC5sZW5ndGggPiAwKSB7XG4gICAgbGV0IGVudHJpZXNSZXMgPSBhd2FpdCBjZWxsLmNhbGxab21lKHtcbiAgICAgIHpvbWVfbmFtZTogJ2hyZWEnLFxuICAgICAgZm5fbmFtZTogJ2dldF9nZW5lcmljX2VudHJpZXMnLFxuICAgICAgcGF5bG9hZDogdG9GZXRjaCxcbiAgICB9KVxuXG4gICAgZW50cmllc1Jlcy5mb3JFYWNoKChyZXM6IGFueSkgPT4ge1xuICAgICAgaWYgKHJlcz8uZW50cnk/LlByZXNlbnQpIHtcbiAgICAgICAgY29uc3QgZGVjb2RlZCA9IGRlY29kZShyZXMuZW50cnkuUHJlc2VudC5lbnRyeSlcbiAgICAgICAgY29uc3QgY2FtZWxDYXNlZCA9IHNuYWtlVG9DYW1lbChkZWNvZGVkKVxuICAgICAgICBjb25zdCB3aXRoSWRzID0ge1xuICAgICAgICAgIC4uLmNhbWVsQ2FzZWQsIFxuICAgICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgICBpZDogZGVjb2RlZD8uaWQgPyBlbmNvZGVIYXNoVG9CYXNlNjQoZGVjb2RlZC5pZCkgOiBlbmNvZGVIYXNoVG9CYXNlNjQocmVzLnNpZ25lZF9hY3Rpb24uaGFzaGVkLmhhc2gpLCBcbiAgICAgICAgICByZXZpc2lvbklkOiBlbmNvZGVIYXNoVG9CYXNlNjQocmVzLnNpZ25lZF9hY3Rpb24uaGFzaGVkLmhhc2gpLFxuICAgICAgICAgIG1ldGE6IHtcbiAgICAgICAgICAgIHJldHJpZXZlZFJldmlzaW9uOiB7XG4gICAgICAgICAgICAgIGlkOiBlbmNvZGVIYXNoVG9CYXNlNjQocmVzLnNpZ25lZF9hY3Rpb24uaGFzaGVkLmhhc2gpLFxuICAgICAgICAgICAgICB0aW1lOiBhY3Rpb25UaW1lc3RhbXAocmVzLnNpZ25lZF9hY3Rpb24uaGFzaGVkLmNvbnRlbnQpLFxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjb25zdCB3aXRoRm9ybWF0dGVkRGF0ZXMgPSBmb3JtYXREYXRlcyh3aXRoSWRzKVxuICAgICAgICBhZGRFbnRyeVRvU3RvcmUod2l0aElkcy5yZXZpc2lvbklkLCB3aXRoRm9ybWF0dGVkRGF0ZXMpXG4gICAgICAgIHVwZGF0ZUxhdGVzdFJldmlzaW9uKFxuICAgICAgICAgIHdpdGhGb3JtYXR0ZWREYXRlcy5pZCxcbiAgICAgICAgICB3aXRoRm9ybWF0dGVkRGF0ZXNcbiAgICAgICAgKVxuICAgICAgICBlbnRyaWVzLnB1c2god2l0aEZvcm1hdHRlZERhdGVzKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc29sZS5sb2coYE5vIGVudHJ5IGZvciBpdGVtcyAoJHtsaXN0fSlgLCByZXMpXG4gICAgICB9XG4gICAgfSlcbiAgfVxuICByZXR1cm4gZW50cmllc1xufVxuXG4vKipcbiAqIFRpbWVzdGFtcCBvZiBhIHNpZ25lZCBhY3Rpb24sIGFjcm9zcyB0aGUgMC42IGFuZCAwLjcgYWN0aW9uIHNoYXBlcy5cbiAqXG4gKiBIb2xvY2hhaW4gMC43IHNwbGl0cyBhbiBBY3Rpb24gaW50byBgeyBoZWFkZXIsIGRhdGEgfWA6IHRoZSBmaWVsZHMgZXZlcnlcbiAqIHZhcmlhbnQgc2hhcmVzIChhdXRob3IsIHRpbWVzdGFtcCwgYWN0aW9uX3NlcSwgcHJldl9hY3Rpb24pIG1vdmVkIHVuZGVyXG4gKiBgaGVhZGVyYCwgYW5kIHRoZSB2YXJpYW50IHBheWxvYWQgdW5kZXIgYGRhdGFgLiBPbiAwLjYgdGhleSBzYXQgZmxhdCBvblxuICogYGNvbnRlbnRgLiBSZWFkaW5nIG9ubHkgdGhlIDAuNyBwYXRoIHdvdWxkIGJyZWFrIGFueSBjb25zdW1lciBzdGlsbCBvbiAwLjYsXG4gKiBhbmQgcmVhZGluZyBvbmx5IHRoZSAwLjYgcGF0aCBpcyB3aGF0IG1hZGUgYG1ldGEucmV0cmlldmVkUmV2aXNpb24udGltZWBcbiAqIGNvbWUgYmFjayBlbXB0eSBvbiAwLjcuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhY3Rpb25UaW1lc3RhbXAoY29udGVudDogYW55KTogYW55IHtcbiAgcmV0dXJuIGNvbnRlbnQ/LmhlYWRlcj8udGltZXN0YW1wID8/IGNvbnRlbnQ/LnRpbWVzdGFtcFxufVxuXG5leHBvcnQgZnVuY3Rpb24gZm9ybWF0UmVzSXRlbShyZXNJdGVtOiBhbnksIGlkOiBzdHJpbmcpIHtcbiAgaWYgKCFyZXNJdGVtPy5lbnRyeT8uUHJlc2VudD8uZW50cnkpIHsgcmV0dXJuIG51bGwgfVxuICBsZXQgZGVjb2RlZCA9IGRlY29kZShyZXNJdGVtLmVudHJ5LlByZXNlbnQuZW50cnkpXG4gIGxldCBjYW1lbCA9IHNuYWtlVG9DYW1lbChkZWNvZGVkKVxuICBsZXQgd2l0aElkID0ge1xuICAgIC4uLmNhbWVsLCBcbiAgICBpZDogIGlkLFxuICAgIHJldmlzaW9uSWQ6IGVuY29kZUhhc2hUb0Jhc2U2NChyZXNJdGVtLnNpZ25lZF9hY3Rpb24uaGFzaGVkLmhhc2gpLFxuICAgIG1ldGE6IHtcbiAgICAgIHJldHJpZXZlZFJldmlzaW9uOiB7XG4gICAgICAgIGlkOiBlbmNvZGVIYXNoVG9CYXNlNjQocmVzSXRlbS5zaWduZWRfYWN0aW9uLmhhc2hlZC5oYXNoKSxcbiAgICAgICAgdGltZTogYWN0aW9uVGltZXN0YW1wKHJlc0l0ZW0uc2lnbmVkX2FjdGlvbi5oYXNoZWQuY29udGVudCksXG4gICAgICB9XG4gICAgfVxuICB9XG4gIGxldCBlbmNvZGVkID0gZm9ybWF0RGF0ZXMod2l0aElkKVxuICByZXR1cm4gZW5jb2RlZFxufVxuXG5leHBvcnQgZnVuY3Rpb24gc25ha2VUb0NhbWVsU3RyaW5nKHN0cjogc3RyaW5nKSB7XG4gIC8vIGNvbnZlcnQgYSBzbmFrZV9jYXNlIHN0cmluZyB0byBjYW1lbENhc2VcbiAgcmV0dXJuIHN0ci5yZXBsYWNlKC9fKFthLXpdKS9nLCBmdW5jdGlvbiAoZykgeyByZXR1cm4gZ1sxXS50b1VwcGVyQ2FzZSgpOyB9KTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHNuYWtlVG9DYW1lbChsaWI6IGFueSk6IGFueSB7XG4gIC8vIFJlY3Vyc2l2ZWx5IGNvbnZlcnQgYWxsIGtleXMgZnJvbSBzbmFrZV9jYXNlIHRvIGNhbWVsQ2FzZVxuICAvLyBEbyBub3QgY29udmVydCBpZiBpdCdzIGEgaGFzaCAob2JqZWN0IHdpdGggb25seSBudW1lcmljIGtleXMpXG4gIGlmIChBcnJheS5pc0FycmF5KGxpYikpIHtcbiAgICByZXR1cm4gbGliLm1hcChzbmFrZVRvQ2FtZWwpO1xuICB9IGVsc2UgaWYgKGxpYiAhPT0gbnVsbCAmJiB0eXBlb2YgbGliID09PSAnb2JqZWN0Jykge1xuICAgIC8vIENoZWNrIGlmIGFsbCBrZXlzIGFyZSBudW1lcmljIChoYXNoIG9iamVjdClcbiAgICBjb25zdCBrZXlzID0gT2JqZWN0LmtleXMobGliKTtcbiAgICBjb25zdCBhbGxOdW1lcmljID0ga2V5cy5sZW5ndGggPiAwICYmIGtleXMuZXZlcnkoayA9PiAvXlxcZCskLy50ZXN0KGspKTtcbiAgICBpZiAoYWxsTnVtZXJpYykge1xuICAgICAgcmV0dXJuIGxpYjtcbiAgICB9XG4gICAgbGV0IGNhbWVsOiBhbnkgPSB7fTtcbiAgICBmb3IgKGxldCBrZXkgaW4gbGliKSB7XG4gICAgICBsZXQgY2FtZWxLZXkgPSBrZXkucmVwbGFjZSgvXyhbYS16XSkvZywgZnVuY3Rpb24gKGcpIHsgcmV0dXJuIGdbMV0udG9VcHBlckNhc2UoKTsgfSk7XG4gICAgICAvLyBjb252ZXJ0IHJlYV9hY3Rpb25cbiAgICAgIGlmIChjYW1lbEtleSA9PT0gXCJyZWFBY3Rpb25cIikge1xuICAgICAgICBjYW1lbEtleSA9IFwiYWN0aW9uXCI7XG4gICAgICB9XG4gICAgICBjb25zdCB2YWx1ZSA9IGxpYltrZXldO1xuICAgICAgY2FtZWxbY2FtZWxLZXldID0gKHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgdmFsdWUgIT09IG51bGwpXG4gICAgICAgID8gc25ha2VUb0NhbWVsKHZhbHVlKVxuICAgICAgICA6IHZhbHVlO1xuICAgIH1cbiAgICByZXR1cm4gY2FtZWw7XG4gIH1cbiAgcmV0dXJuIGxpYjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNhbWVsVG9TbmFrZShsaWI6IGFueSk6IGFueSB7XG4gIC8vIFJlY3Vyc2l2ZWx5IGNvbnZlcnQgYWxsIGtleXMgZnJvbSBjYW1lbENhc2UgdG8gc25ha2VfY2FzZVxuICBpZiAoQXJyYXkuaXNBcnJheShsaWIpKSB7XG4gICAgcmV0dXJuIGxpYi5tYXAoY2FtZWxUb1NuYWtlKTtcbiAgfSBlbHNlIGlmIChsaWIgIT09IG51bGwgJiYgdHlwZW9mIGxpYiA9PT0gJ29iamVjdCcpIHtcbiAgICBsZXQgc25ha2U6IGFueSA9IHt9O1xuICAgIGZvciAobGV0IGtleSBpbiBsaWIpIHtcbiAgICAgIGxldCBzbmFrZUtleSA9IGtleS5yZXBsYWNlKC8oW0EtWl0pL2csIFwiXyQxXCIpLnRvTG93ZXJDYXNlKCk7XG4gICAgICAvLyBjb252ZXJ0IGFjdGlvblxuICAgICAgaWYgKHNuYWtlS2V5ID09PSBcImFjdGlvblwiKSB7XG4gICAgICAgIHNuYWtlS2V5ID0gXCJyZWFfYWN0aW9uXCI7XG4gICAgICB9XG4gICAgICAvLyB0dXJuIG51bGwgdmFsdWVzIGludG8gdW5kZWZpbmVkXG4gICAgICBsZXQgdmFsdWUgPSBsaWJba2V5XSA9PT0gbnVsbCA/IHVuZGVmaW5lZCA6IGxpYltrZXldO1xuICAgICAgLy8gcmVjdXJzaXZlbHkgY29udmVydCBvYmplY3RzIGFuZCBhcnJheXNcbiAgICAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHZhbHVlICE9PSBudWxsKSB7XG4gICAgICAgIHZhbHVlID0gY2FtZWxUb1NuYWtlKHZhbHVlKTtcbiAgICAgIH1cbiAgICAgIHNuYWtlW3NuYWtlS2V5XSA9IHZhbHVlO1xuICAgIH1cbiAgICByZXR1cm4gc25ha2U7XG4gIH1cbiAgcmV0dXJuIGxpYjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGRldGVjdFF1YW50aXR5VmFsdWVGaWVsZChmaWVsZDogYW55KSB7XG4gIGlmIChmaWVsZC5oYXNfbnVtZXJpY2FsX3ZhbHVlICE9PSB1bmRlZmluZWQgJiYgZmllbGQuaGFzX3VuaXQgIT09IHVuZGVmaW5lZCkge1xuICAgIHJldHVybiB0cnVlXG4gIH1cbiAgcmV0dXJuIGZhbHNlXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkZWNvZGVQb3RlbnRpYWxRdWFudGl0eVZhbHVlRmllbGQoZmllbGQ6IGFueSkge1xuICBpZiAoZmllbGQuaGFzTnVtZXJpY2FsVmFsdWUgIT09IHVuZGVmaW5lZCAmJiBmaWVsZC5oYXNVbml0ICE9PSB1bmRlZmluZWQpIHtcbiAgICByZXR1cm4ge1xuICAgICAgaGFzX251bWVyaWNhbF92YWx1ZTogZmllbGQuaGFzTnVtZXJpY2FsVmFsdWUsXG4gICAgICBoYXNfdW5pdDogZmllbGQuaGFzVW5pdD8uaWQgPyBmaWVsZC5oYXNVbml0LmlkIDogKGZpZWxkLmhhc1VuaXQgPyBmaWVsZC5oYXNVbml0IDogbnVsbClcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGZpZWxkXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBmaW5kQW5kRGVjb2RlUXVhbnRpdHlWYWx1ZUZpZWxkcyhvYmo6IGFueSkge1xuICBmb3IgKGxldCBrZXkgaW4gb2JqKSB7XG4gICAgaWYgKHR5cGVvZiBvYmpba2V5XSA9PT0gJ29iamVjdCcgJiYgb2JqW2tleV0gIT09IG51bGwpIHtcbiAgICAgIGlmIChvYmpba2V5XS5oYXNOdW1lcmljYWxWYWx1ZSAhPT0gdW5kZWZpbmVkICYmIG9ialtrZXldLmhhc1VuaXQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICBvYmpba2V5XSA9IGRlY29kZVBvdGVudGlhbFF1YW50aXR5VmFsdWVGaWVsZChvYmpba2V5XSlcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIG9ialxufVxuXG4vLyBjb25zdCBkYXRlRmllbGRzID0gWydkdWUnLCAnaGFzQmVnaW5uaW5nJywgJ2hhc0VuZCcsICdoYXNQb2ludEluVGltZSddXG4vLyBleHBvcnQgZnVuY3Rpb24gZm9ybWF0RGF0ZXMob2JqOiBhbnkpIHtcbi8vICAgZGF0ZUZpZWxkcy5mb3JFYWNoKGZpZWxkID0+IHtcbi8vICAgICBpZiAob2JqW2ZpZWxkXSkge1xuLy8gICAgICAgb2JqW2ZpZWxkXSA9IG5ldyBEYXRlKG9ialtmaWVsZF0gLyAxMDAwKVxuLy8gICAgIH1cbi8vICAgfSlcbi8vICAgcmV0dXJuIG9ialxuLy8gfVxuXG4vLyBleHBvcnQgZnVuY3Rpb24gcmV2ZXJzZUZvcm1hdERhdGVzKG9iajogYW55KSB7XG4vLyAgIGRhdGVGaWVsZHMuZm9yRWFjaChmaWVsZCA9PiB7XG4vLyAgICAgaWYgKG9ialtmaWVsZF0pIHtcbi8vICAgICAgIG9ialtmaWVsZF0gPSBuZXcgRGF0ZShvYmpbZmllbGRdKS5nZXRUaW1lKCkgKiAxMDAwXG4vLyAgICAgfVxuLy8gICB9KVxuLy8gICByZXR1cm4gb2JqXG4vLyB9XG5jb25zdCBkYXRlRmllbGRzID0gWydkdWUnLCAnaGFzQmVnaW5uaW5nJywgJ2hhc0VuZCcsICdoYXNQb2ludEluVGltZSddXG5leHBvcnQgZnVuY3Rpb24gZm9ybWF0RGF0ZXMob2JqOiBhbnkpIHtcbiAgZGF0ZUZpZWxkcy5mb3JFYWNoKGZpZWxkID0+IHtcbiAgICBpZiAob2JqW2ZpZWxkXSkge1xuICAgICAgLy8gT25seSBjb252ZXJ0IGlmIG5vdCBhbHJlYWR5IGEgRGF0ZVxuICAgICAgaWYgKCEob2JqW2ZpZWxkXSBpbnN0YW5jZW9mIERhdGUpKSB7XG4gICAgICAgIC8vIGlmIGl0IGlzIGEgbnVtYmVyLCBhc3N1bWUgaXQncyBhIHRpbWVzdGFtcFxuICAgICAgICBpZiAodHlwZW9mIG9ialtmaWVsZF0gPT09ICdudW1iZXInKSB7XG4gICAgICAgICAgb2JqW2ZpZWxkXSA9IG5ldyBEYXRlKG9ialtmaWVsZF0gLyAxMDAwKVxuICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiBvYmpbZmllbGRdID09PSAnc3RyaW5nJykge1xuICAgICAgICAgIC8vIGlmIGl0J3MgYSBzdHJpbmcsIHRyeSB0byBwYXJzZSBpdCBhcyBhIGRhdGVcbiAgICAgICAgICBjb25zdCBwYXJzZWREYXRlID0gbmV3IERhdGUob2JqW2ZpZWxkXSlcbiAgICAgICAgICBpZiAoIWlzTmFOKHBhcnNlZERhdGUuZ2V0VGltZSgpKSkge1xuICAgICAgICAgICAgb2JqW2ZpZWxkXSA9IHBhcnNlZERhdGVcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH0pXG4gIHJldHVybiBvYmpcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHJldmVyc2VGb3JtYXREYXRlcyhvYmo6IGFueSkge1xuICBkYXRlRmllbGRzLmZvckVhY2goZmllbGQgPT4ge1xuICAgIGlmIChvYmpbZmllbGRdKSB7XG4gICAgICAvLyBPbmx5IGNvbnZlcnQgaWYgbm90IGFscmVhZHkgYSBudW1iZXIgKHRpbWVzdGFtcClcbiAgICAgIGlmIChvYmpbZmllbGRdIGluc3RhbmNlb2YgRGF0ZSkge1xuICAgICAgICBvYmpbZmllbGRdID0gb2JqW2ZpZWxkXS5nZXRUaW1lKCkgKiAxMDAwXG4gICAgICB9IGVsc2UgaWYgKHR5cGVvZiBvYmpbZmllbGRdID09PSAnc3RyaW5nJykge1xuICAgICAgICAvLyBpZiBpdCdzIGEgc3RyaW5nLCB0cnkgdG8gcGFyc2UgaXQgYXMgYSBkYXRlXG4gICAgICAgIGNvbnN0IHBhcnNlZERhdGUgPSBuZXcgRGF0ZShvYmpbZmllbGRdKVxuICAgICAgICBpZiAoIWlzTmFOKHBhcnNlZERhdGUuZ2V0VGltZSgpKSkge1xuICAgICAgICAgIG9ialtmaWVsZF0gPSBwYXJzZWREYXRlLmdldFRpbWUoKSAqIDEwMDBcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfSlcbiAgcmV0dXJuIG9ialxufVxuXG5leHBvcnQgZnVuY3Rpb24gcGx1cmFsaXplKHN0cjogc3RyaW5nKSB7XG4gIGlmIChzdHIgPT09ICdwZXJzb24nKSB7XG4gICAgcmV0dXJuICdwZW9wbGUnXG4gIH0gZWxzZSBpZiAoc3RyLmVuZHNXaXRoKCdzJykpIHtcbiAgICByZXR1cm4gc3RyICsgJ2VzJ1xuICB9IGVsc2UgaWYgKHN0ci5lbmRzV2l0aCgneScpKSB7XG4gICAgcmV0dXJuIHN0ci5zbGljZSgwLCAtMSkgKyAnaWVzJ1xuICB9IGVsc2UgaWYgKHN0ci5lbmRzV2l0aCgnbycpKSB7XG4gICAgcmV0dXJuIHN0ciArICdlcydcbiAgfSBlbHNlIGlmIChzdHIuZW5kc1dpdGgoJ2NoJykpIHtcbiAgICByZXR1cm4gc3RyICsgJ2VzJ1xuICB9IGVsc2UgaWYgKHN0ci5lbmRzV2l0aCgnc2gnKSkge1xuICAgIHJldHVybiBzdHIgKyAnZXMnXG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIHN0ciArICdzJ1xuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkZWNvZGVIYXNoRmllbGRzKG9iajogYW55LCBoYXNoRmllbGRzOiBzdHJpbmdbXSkge1xuICBoYXNoRmllbGRzLmZvckVhY2goZmllbGQgPT4ge1xuICAgIGlmIChvYmpbZmllbGRdKSB7XG4gICAgICBjb25zdCBkZWNvZGVkRmllbGQgPSBkZWNvZGVIYXNoRnJvbUJhc2U2NChvYmpbZmllbGRdKVxuICAgICAgb2JqW2ZpZWxkXSA9IGRlY29kZWRGaWVsZFxuICAgICAgb2JqW2Ake2ZpZWxkfUlkYF0gPSBkZWNvZGVkRmllbGRcbiAgICB9XG4gIH0pXG4gIHJldHVybiBvYmpcbn1cblxuY29uc3QgYWN0aW9ucyA9IHtcbiAgXCJkcm9wb2ZmXCI6IHtcbiAgICBpZDogXCJkcm9wb2ZmXCIsXG4gICAgbGFiZWw6IFwiZHJvcG9mZlwiLFxuICAgIHJlc291cmNlRWZmZWN0OiBcImRlY3JlbWVudFwiLFxuICAgIG9uaGFuZEVmZmVjdDogXCJkZWNyZW1lbnRcIixcbiAgICBpbnB1dE91dHB1dDogXCJvdXRwdXRcIixcbiAgICBwYWlyc1dpdGg6IFwicGlja3VwXCJcbiAgfSxcbiAgXCJwaWNrdXBcIjoge1xuICAgIGlkOiBcInBpY2t1cFwiLFxuICAgIGxhYmVsOiBcInBpY2t1cFwiLFxuICAgIHJlc291cmNlRWZmZWN0OiBcImluY3JlbWVudFwiLFxuICAgIG9uaGFuZEVmZmVjdDogXCJpbmNyZW1lbnRcIixcbiAgICBpbnB1dE91dHB1dDogXCJpbnB1dFwiLFxuICAgIHBhaXJzV2l0aDogXCJkcm9wb2ZmXCJcbiAgfSxcbiAgXCJjb25zdW1lXCI6IHtcbiAgICBpZDogXCJjb25zdW1lXCIsXG4gICAgbGFiZWw6IFwiY29uc3VtZVwiLFxuICAgIHJlc291cmNlRWZmZWN0OiBcImRlY3JlbWVudFwiLFxuICAgIG9uaGFuZEVmZmVjdDogXCJkZWNyZW1lbnRcIixcbiAgICBpbnB1dE91dHB1dDogXCJpbnB1dFwiLFxuICAgIHBhaXJzV2l0aDogXCJub3RBcHBsaWNhYmxlXCJcbiAgfSxcbiAgXCJ1c2VcIjoge1xuICAgIGlkOiBcInVzZVwiLFxuICAgIGxhYmVsOiBcInVzZVwiLFxuICAgIHJlc291cmNlRWZmZWN0OiBcIm5vRWZmZWN0XCIsXG4gICAgb25oYW5kRWZmZWN0OiBcIm5vRWZmZWN0XCIsXG4gICAgaW5wdXRPdXRwdXQ6IFwiaW5wdXRcIixcbiAgICBwYWlyc1dpdGg6IFwibm90QXBwbGljYWJsZVwiXG4gIH0sXG4gIFwid29ya1wiOiB7XG4gICAgaWQ6IFwid29ya1wiLFxuICAgIGxhYmVsOiBcIndvcmtcIixcbiAgICByZXNvdXJjZUVmZmVjdDogXCJub0VmZmVjdFwiLFxuICAgIG9uaGFuZEVmZmVjdDogXCJub0VmZmVjdFwiLFxuICAgIGlucHV0T3V0cHV0OiBcImlucHV0XCIsXG4gICAgcGFpcnNXaXRoOiBcIm5vdEFwcGxpY2FibGVcIlxuICB9LFxuICBcImNpdGVcIjoge1xuICAgIGlkOiBcImNpdGVcIixcbiAgICBsYWJlbDogXCJjaXRlXCIsXG4gICAgcmVzb3VyY2VFZmZlY3Q6IFwibm9FZmZlY3RcIixcbiAgICBvbmhhbmRFZmZlY3Q6IFwibm9FZmZlY3RcIixcbiAgICBpbnB1dE91dHB1dDogXCJpbnB1dFwiLFxuICAgIHBhaXJzV2l0aDogXCJub3RBcHBsaWNhYmxlXCJcbiAgfSxcbiAgXCJwcm9kdWNlXCI6IHtcbiAgICBpZDogXCJwcm9kdWNlXCIsXG4gICAgbGFiZWw6IFwicHJvZHVjZVwiLFxuICAgIHJlc291cmNlRWZmZWN0OiBcImluY3JlbWVudFwiLFxuICAgIG9uaGFuZEVmZmVjdDogXCJpbmNyZW1lbnRcIixcbiAgICBpbnB1dE91dHB1dDogXCJvdXRwdXRcIixcbiAgICBwYWlyc1dpdGg6IFwibm90QXBwbGljYWJsZVwiXG4gIH0sXG4gIFwiYWNjZXB0XCI6IHtcbiAgICBpZDogXCJhY2NlcHRcIixcbiAgICBsYWJlbDogXCJhY2NlcHRcIixcbiAgICByZXNvdXJjZUVmZmVjdDogXCJub0VmZmVjdFwiLFxuICAgIG9uaGFuZEVmZmVjdDogXCJkZWNyZW1lbnRcIixcbiAgICBpbnB1dE91dHB1dDogXCJpbnB1dFwiLFxuICAgIHBhaXJzV2l0aDogXCJtb2RpZnlcIlxuICB9LFxuICBcIm1vZGlmeVwiOiB7XG4gICAgaWQ6IFwibW9kaWZ5XCIsXG4gICAgbGFiZWw6IFwibW9kaWZ5XCIsXG4gICAgcmVzb3VyY2VFZmZlY3Q6IFwibm9FZmZlY3RcIixcbiAgICBvbmhhbmRFZmZlY3Q6IFwiaW5jcmVtZW50XCIsXG4gICAgaW5wdXRPdXRwdXQ6IFwib3V0cHV0XCIsXG4gICAgcGFpcnNXaXRoOiBcImFjY2VwdFwiXG4gIH0sXG4gIFwicGFzc1wiOiB7XG4gICAgaWQ6IFwicGFzc1wiLFxuICAgIGxhYmVsOiBcInBhc3NcIixcbiAgICByZXNvdXJjZUVmZmVjdDogXCJub0VmZmVjdFwiLFxuICAgIG9uaGFuZEVmZmVjdDogXCJub0VmZmVjdFwiLFxuICAgIGlucHV0T3V0cHV0OiBcIm91dHB1dFwiLFxuICAgIHBhaXJzV2l0aDogXCJhY2NlcHRcIlxuICB9LFxuICBcImZhaWxcIjoge1xuICAgIGlkOiBcImZhaWxcIixcbiAgICBsYWJlbDogXCJmYWlsXCIsXG4gICAgcmVzb3VyY2VFZmZlY3Q6IFwibm9FZmZlY3RcIixcbiAgICBvbmhhbmRFZmZlY3Q6IFwibm9FZmZlY3RcIixcbiAgICBpbnB1dE91dHB1dDogXCJvdXRwdXRcIixcbiAgICBwYWlyc1dpdGg6IFwiYWNjZXB0XCJcbiAgfSxcbiAgXCJjb21iaW5lXCI6IHtcbiAgICBpZDogXCJjb21iaW5lXCIsXG4gICAgbGFiZWw6IFwiY29tYmluZVwiLFxuICAgIHJlc291cmNlRWZmZWN0OiBcIm5vRWZmZWN0XCIsXG4gICAgb25oYW5kRWZmZWN0OiBcImRlY3JlbWVudFwiLFxuICAgIGlucHV0T3V0cHV0OiBcImlucHV0XCIsXG4gICAgcGFpcnNXaXRoOiBcIm5vdEFwcGxpY2FibGVcIlxuICB9LFxuICBcInNlcGFyYXRlXCI6IHtcbiAgICBpZDogXCJzZXBhcmF0ZVwiLFxuICAgIGxhYmVsOiBcInNlcGFyYXRlXCIsXG4gICAgcmVzb3VyY2VFZmZlY3Q6IFwibm9FZmZlY3RcIixcbiAgICBvbmhhbmRFZmZlY3Q6IFwiaW5jcmVtZW50XCIsXG4gICAgaW5wdXRPdXRwdXQ6IFwib3V0cHV0XCIsXG4gICAgcGFpcnNXaXRoOiBcIm5vdEFwcGxpY2FibGVcIlxuICB9LFxuICBcImNvcHlcIjoge1xuICAgIGlkOiBcImNvcHlcIixcbiAgICBsYWJlbDogXCJjb3B5XCIsXG4gICAgcmVzb3VyY2VFZmZlY3Q6IFwiaW5jcmVtZW50XCIsXG4gICAgb25oYW5kRWZmZWN0OiBcImluY3JlbWVudFwiLFxuICAgIGlucHV0T3V0cHV0OiBcIm5vdEFwcGxpY2FibGVcIixcbiAgICBwYWlyc1dpdGg6IFwibm90QXBwbGljYWJsZVwiXG4gIH0sXG4gIFwiZGVsaXZlci1zZXJ2aWNlXCI6IHtcbiAgICBpZDogXCJkZWxpdmVyLXNlcnZpY2VcIixcbiAgICBsYWJlbDogXCJkZWxpdmVyLXNlcnZpY2VcIixcbiAgICByZXNvdXJjZUVmZmVjdDogXCJub0VmZmVjdFwiLFxuICAgIG9uaGFuZEVmZmVjdDogXCJub0VmZmVjdFwiLFxuICAgIGlucHV0T3V0cHV0OiBcIm91dHB1dFwiLFxuICAgIHBhaXJzV2l0aDogXCJub3RBcHBsaWNhYmxlXCJcbiAgfSxcbiAgXCJ0cmFuc2Zlci1hbGwtcmlnaHRzXCI6IHtcbiAgICBpZDogXCJ0cmFuc2Zlci1hbGwtcmlnaHRzXCIsXG4gICAgbGFiZWw6IFwidHJhbnNmZXItYWxsLXJpZ2h0c1wiLFxuICAgIHJlc291cmNlRWZmZWN0OiBcImRlY3JlbWVudEluY3JlbWVudFwiLFxuICAgIG9uaGFuZEVmZmVjdDogXCJub0VmZmVjdFwiLFxuICAgIGlucHV0T3V0cHV0OiBcIm5vdEFwcGxpY2FibGVcIixcbiAgICBwYWlyc1dpdGg6IFwibm90QXBwbGljYWJsZVwiXG4gIH0sXG4gIFwidHJhbnNmZXItY3VzdG9keVwiOiB7XG4gICAgaWQ6IFwidHJhbnNmZXItY3VzdG9keVwiLFxuICAgIGxhYmVsOiBcInRyYW5zZmVyLWN1c3RvZHlcIixcbiAgICByZXNvdXJjZUVmZmVjdDogXCJub0VmZmVjdFwiLFxuICAgIG9uaGFuZEVmZmVjdDogXCJkZWNyZW1lbnRJbmNyZW1lbnRcIixcbiAgICBpbnB1dE91dHB1dDogXCJub3RBcHBsaWNhYmxlXCIsXG4gICAgcGFpcnNXaXRoOiBcIm5vdEFwcGxpY2FibGVcIlxuICB9LFxuICBcInRyYW5zZmVyXCI6IHtcbiAgICBpZDogXCJ0cmFuc2ZlclwiLFxuICAgIGxhYmVsOiBcInRyYW5zZmVyXCIsXG4gICAgcmVzb3VyY2VFZmZlY3Q6IFwiZGVjcmVtZW50SW5jcmVtZW50XCIsXG4gICAgb25oYW5kRWZmZWN0OiBcImRlY3JlbWVudEluY3JlbWVudFwiLFxuICAgIGlucHV0T3V0cHV0OiBcIm5vdEFwcGxpY2FibGVcIixcbiAgICBwYWlyc1dpdGg6IFwibm90QXBwbGljYWJsZVwiXG4gIH0sXG4gIFwibW92ZVwiOiB7XG4gICAgaWQ6IFwibW92ZVwiLFxuICAgIGxhYmVsOiBcIm1vdmVcIixcbiAgICByZXNvdXJjZUVmZmVjdDogXCJkZWNyZW1lbnRJbmNyZW1lbnRcIixcbiAgICBvbmhhbmRFZmZlY3Q6IFwiZGVjcmVtZW50SW5jcmVtZW50XCIsXG4gICAgaW5wdXRPdXRwdXQ6IFwibm90QXBwbGljYWJsZVwiLFxuICAgIHBhaXJzV2l0aDogXCJub3RBcHBsaWNhYmxlXCJcbiAgfSxcbiAgXCJyYWlzZVwiOiB7XG4gICAgaWQ6IFwicmFpc2VcIixcbiAgICBsYWJlbDogXCJyYWlzZVwiLFxuICAgIHJlc291cmNlRWZmZWN0OiBcImluY3JlbWVudFwiLFxuICAgIG9uaGFuZEVmZmVjdDogXCJpbmNyZW1lbnRcIixcbiAgICBpbnB1dE91dHB1dDogXCJub3RBcHBsaWNhYmxlXCIsXG4gICAgcGFpcnNXaXRoOiBcIm5vdEFwcGxpY2FibGVcIlxuICB9LFxuICBcImxvd2VyXCI6IHtcbiAgICBpZDogXCJsb3dlclwiLFxuICAgIGxhYmVsOiBcImxvd2VyXCIsXG4gICAgcmVzb3VyY2VFZmZlY3Q6IFwiZGVjcmVtZW50XCIsXG4gICAgb25oYW5kRWZmZWN0OiBcImRlY3JlbWVudFwiLFxuICAgIGlucHV0T3V0cHV0OiBcIm5vdEFwcGxpY2FibGVcIixcbiAgICBwYWlyc1dpdGg6IFwibm90QXBwbGljYWJsZVwiXG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldEFjdGlvbihpZDogc3RyaW5nKSB7XG4gIHJldHVybiBhY3Rpb25zW2lkXVxufSJdfQ==